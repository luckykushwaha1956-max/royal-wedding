/* Paste this into Google Sheet > Extensions > Apps Script, then Deploy > New deployment
   > Web app > Execute as: Me > Who has access: Anyone. Copy the Web app URL into
   weddingConfig.js  ->  rsvp.endpoint                                              */
function doPost(e) {
  try {
    var d = JSON.parse(e.postData.contents);
    var sh = SpreadsheetApp.getActiveSheet();
    if (sh.getLastRow() === 0) sh.appendRow(['Received', 'Name', 'Phone', 'Attending', 'Guests', 'Message']);
    sh.appendRow([new Date(), d.name, d.phone, d.attending, d.guests, d.message]);
    return ContentService.createTextOutput(JSON.stringify({ ok: true })).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ ok: false, error: String(err) })).setMimeType(ContentService.MimeType.JSON);
  }
}
