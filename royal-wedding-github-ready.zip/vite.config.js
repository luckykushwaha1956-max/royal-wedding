import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base './' makes the built site work on any host or sub-folder
// (Netlify, Vercel, GitHub Pages, cPanel, etc.)
export default defineConfig({
  base: './',
  plugins: [react()],
  build: {
    chunkSizeWarningLimit: 900,
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes('node_modules/framer-motion') || id.includes('node_modules/motion-')) return 'motion';
          if (id.includes('node_modules/gsap')) return 'gsap';
        },
      },
    },
  },
});
