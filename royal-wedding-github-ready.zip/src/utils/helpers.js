/* Small shared helpers */

/** Build a URL for a file inside /public (works on any host or sub-folder). */
export const asset = (path = '') =>
  /^(https?:)?\/\//.test(path) || path.startsWith('data:')
    ? path
    : `${import.meta.env.BASE_URL}${path.replace(/^\//, '')}`;

/** "2026-11-26" -> "Thursday, 26 November 2026" */
export function formatLongDate(isoDate) {
  const d = new Date(`${isoDate}T12:00:00Z`);
  return new Intl.DateTimeFormat('en-IN', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    timeZone: 'UTC',
  }).format(d);
}

/** "2026-11-26" -> "26 November 2026" */
export function formatDate(isoDate) {
  const d = new Date(`${isoDate}T12:00:00Z`);
  return new Intl.DateTimeFormat('en-IN', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    timeZone: 'UTC',
  }).format(d);
}

/** Parts for a big date display */
export function dateParts(isoDate) {
  const d = new Date(`${isoDate}T12:00:00Z`);
  const f = (opt) => new Intl.DateTimeFormat('en-IN', { ...opt, timeZone: 'UTC' }).format(d);
  return {
    day: f({ day: 'numeric' }),
    month: f({ month: 'long' }),
    year: f({ year: 'numeric' }),
    weekday: f({ weekday: 'long' }),
  };
}

/** "20:00" -> "8:00 PM" */
export function formatTime24(t) {
  const [h, m] = t.split(':').map(Number);
  const ampm = h >= 12 ? 'PM' : 'AM';
  const hh = h % 12 === 0 ? 12 : h % 12;
  return `${hh}:${String(m).padStart(2, '0')} ${ampm}`;
}

/** Google Maps helpers */
export const mapsEmbedUrl = (query) =>
  `https://www.google.com/maps?q=${encodeURIComponent(query)}&output=embed`;

export const mapsDirectionsUrl = (query) =>
  `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(query)}`;

export const mapsSearchUrl = (query) =>
  `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;

export const clamp = (n, min, max) => Math.min(max, Math.max(min, n));

export const prefersReducedMotion = () =>
  typeof window !== 'undefined' &&
  window.matchMedia &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches;

export const isCoarsePointer = () =>
  typeof window !== 'undefined' &&
  window.matchMedia &&
  window.matchMedia('(pointer: coarse)').matches;
