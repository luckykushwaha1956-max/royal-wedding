import weddingConfig from '../config/weddingConfig';

/** Opens the phone's share sheet. Falls back to copying the link.
 *  Returns 'shared' | 'copied' | 'cancelled' | 'failed'.                */
export async function shareInvitation() {
  const { shareTitle, shareText, shareUrl } = weddingConfig.site;
  const url = shareUrl || window.location.href.split('#')[0];

  if (navigator.share) {
    try {
      await navigator.share({ title: shareTitle, text: shareText, url });
      return 'shared';
    } catch (e) {
      if (e && e.name === 'AbortError') return 'cancelled';
      /* fall through to copy */
    }
  }
  try {
    await navigator.clipboard.writeText(url);
    return 'copied';
  } catch {
    try {
      const ta = document.createElement('textarea');
      ta.value = url;
      ta.setAttribute('readonly', '');
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand('copy');
      document.body.removeChild(ta);
      return ok ? 'copied' : 'failed';
    } catch {
      return 'failed';
    }
  }
}
