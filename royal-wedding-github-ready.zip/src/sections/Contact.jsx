import { useState } from 'react';
import { motion } from 'framer-motion';
import { Check, Mail, MessageCircle, Phone, Share2 } from 'lucide-react';
import weddingConfig from '../config/weddingConfig';
import { Reveal, TextReveal } from '../components/Reveal';
import { GoldDivider, RingsMark } from '../components/Ornaments';
import ParticleField from '../animations/ParticleField';
import { shareInvitation } from '../utils/share';
import { formatDate } from '../utils/helpers';

const { contact, couple, family, wedding, venue } = weddingConfig;

export default function Contact() {
  const [note, setNote] = useState('');

  const doShare = async () => {
    const r = await shareInvitation();
    const msg = { copied: 'Invitation link copied', shared: 'Thank you for sharing', failed: 'Could not share — please copy the page address' }[r];
    if (msg) {
      setNote(msg);
      setTimeout(() => setNote(''), 2800);
    }
  };

  const people = contact.people.filter((p) => p.name);

  return (
    <section
      id="contact"
      aria-labelledby="contact-title"
      className="section relative overflow-hidden pb-32 md:pb-40"
    >
      {/* final cinematic lighting */}
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        <motion.div
          className="absolute left-1/2 top-[38%] h-[120vmin] w-[120vmin] -translate-x-1/2 -translate-y-1/2 rounded-full"
          style={{ background: 'radial-gradient(circle, rgba(243,227,189,0.2), rgba(243,227,189,0) 62%)' }}
          animate={{ scale: [0.9, 1.08, 0.9], opacity: [0.6, 1, 0.6] }}
          transition={{ duration: 9, repeat: Infinity, ease: 'easeInOut' }}
        />
        <div className="absolute inset-0">
          <ParticleField petals={8} dust={48} />
        </div>
      </div>

      <div className="container-x relative">
        <div className="mx-auto max-w-3xl text-center">
          <Reveal>
            <span className="mx-auto mb-6 flex justify-center">
              <RingsMark size={56} />
            </span>
          </Reveal>
          <TextReveal
            as="h2"
            id="contact-title"
            text={contact.thankYou}
            className="gold-text font-display text-[clamp(2.8rem,11vw,5.6rem)] leading-[1.05]"
          />
          <Reveal delay={0.2} className="mt-6">
            <GoldDivider />
          </Reveal>
          <Reveal delay={0.3}>
            <p className="mx-auto mt-6 max-w-xl text-lg leading-relaxed text-pearl/90">{contact.closingMessage}</p>
          </Reveal>

          <Reveal delay={0.4} className="mt-12">
            <p className="font-display text-[clamp(2rem,8vw,3.6rem)] uppercase leading-tight tracking-[0.14em] text-ivory">
              {couple.groom}
            </p>
            <p className="font-script -my-1 text-[clamp(1.8rem,6vw,2.8rem)] text-rose-300">and</p>
            <p className="font-display text-[clamp(2rem,8vw,3.6rem)] uppercase leading-tight tracking-[0.14em] text-ivory">
              {couple.bride}
            </p>
            <p className="mt-5 text-sm tracking-[0.3em] text-pearl/75">{formatDate(wedding.date).toUpperCase()}</p>
            <p className="mt-1 text-sm tracking-[0.15em] text-pearl/60">
              {venue.name}, {venue.city}
            </p>
          </Reveal>
        </div>

        {/* family details */}
        <Reveal delay={0.1} className="mx-auto mt-14 grid max-w-3xl gap-5 text-center sm:grid-cols-2">
          {[family.groomSide, family.brideSide].map((s) => (
            <div key={s.title} className="glass rounded-3xl px-6 py-6">
              <p className="eyebrow !text-[0.66rem]">{s.title}</p>
              <p className="mt-3 font-serif text-xl leading-snug text-ivory">{s.parents.join(' & ')}</p>
            </div>
          ))}
        </Reveal>

        {/* contacts */}
        {(people.length > 0 || contact.email) && (
          <Reveal delay={0.1} className="mx-auto mt-10 max-w-3xl">
            <h3 className="eyebrow mb-5 text-center !text-[0.7rem]">For any help, contact</h3>
            <div className="grid gap-4 sm:grid-cols-2">
              {people.map((p) => {
                const hasPhone = p.phone && p.phone.trim();
                const wa = (p.whatsapp || '').replace(/\D/g, '');
                return (
                  <div key={p.name} className="glass rounded-3xl p-6 text-center">
                    <p className="font-serif text-2xl text-ivory">{p.name}</p>
                    <p className="text-sm text-pearl/70">{p.relation}</p>
                    {(hasPhone || wa) && (
                      <div className="mt-4 flex flex-wrap justify-center gap-2.5">
                        {hasPhone && (
                          <a href={`tel:${p.phone.replace(/[^\d+]/g, '')}`} className="btn-ghost !min-h-11 !px-4 !text-[0.7rem]">
                            <Phone size={15} />
                            Call
                          </a>
                        )}
                        {wa && (
                          <a href={`https://wa.me/${wa}`} target="_blank" rel="noopener noreferrer" className="btn-ghost !min-h-11 !px-4 !text-[0.7rem]">
                            <MessageCircle size={15} />
                            WhatsApp
                          </a>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
            {contact.email && (
              <p className="mt-5 text-center">
                <a href={`mailto:${contact.email}`} className="inline-flex min-h-11 items-center gap-2 text-gold-200 underline-offset-4 hover:underline">
                  <Mail size={16} />
                  {contact.email}
                </a>
              </p>
            )}
          </Reveal>
        )}

        <Reveal delay={0.1} className="mt-12 flex flex-col items-center gap-3">
          <button type="button" onClick={doShare} className="btn-gold">
            <Share2 size={17} />
            Share Invitation
          </button>
          <p className="flex h-6 items-center gap-1.5 text-sm text-gold-200" role="status" aria-live="polite">
            {note && (
              <>
                <Check size={15} />
                {note}
              </>
            )}
          </p>
        </Reveal>
      </div>
    </section>
  );
}
