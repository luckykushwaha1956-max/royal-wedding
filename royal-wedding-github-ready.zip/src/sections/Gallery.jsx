import { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ZoomIn } from 'lucide-react';
import weddingConfig from '../config/weddingConfig';
import SectionHeading from '../components/SectionHeading';
import { Reveal } from '../components/Reveal';
import Lightbox from '../components/Lightbox';
import { asset } from '../utils/helpers';

const { gallery } = weddingConfig;

export default function Gallery() {
  const [filter, setFilter] = useState('all');
  const [open, setOpen] = useState(null); // index inside the filtered list

  const shown = useMemo(
    () => (filter === 'all' ? gallery.images : gallery.images.filter((i) => i.category === filter)),
    [filter],
  );

  const cats = gallery.categories.filter(
    (c) => c.id === 'all' || gallery.images.some((i) => i.category === c.id),
  );

  return (
    <section id="gallery" aria-labelledby="gallery-title" className="section">
      <div className="container-x">
        <SectionHeading
          id="gallery-title"
          eyebrow="Gallery"
          title={gallery.heading}
          subtitle="A few frames from our journey so far. Tap any photo to view it full screen."
        />

        <Reveal delay={0.3} className="mt-9">
          <div role="tablist" aria-label="Filter photos" className="mx-auto flex max-w-3xl flex-wrap justify-center gap-2.5">
            {cats.map((c) => {
              const active = filter === c.id;
              return (
                <button
                  key={c.id}
                  role="tab"
                  type="button"
                  aria-selected={active}
                  onClick={() => setFilter(c.id)}
                  className={`min-h-11 rounded-full border px-5 text-[0.72rem] font-medium uppercase tracking-[0.18em] transition-colors ${
                    active
                      ? 'border-gold-300 bg-gradient-to-br from-gold-200 to-gold-500 text-midnight-900'
                      : 'border-gold-400/35 text-pearl/85 hover:border-gold-300 hover:text-gold-200'
                  }`}
                >
                  {c.label}
                </button>
              );
            })}
          </div>
        </Reveal>

        <motion.ul
          layout
          className="mt-12 grid grid-flow-dense auto-rows-[150px] grid-cols-2 gap-3 sm:auto-rows-[190px] sm:gap-4 lg:grid-cols-3 lg:auto-rows-[230px]"
        >
          <AnimatePresence mode="popLayout">
            {shown.map((img, i) => {
              const tall = img.ratio === 'portrait';
              return (
                <motion.li
                  key={img.src}
                  layout
                  initial={{ opacity: 0, scale: 0.92, y: 24 }}
                  whileInView={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.92 }}
                  viewport={{ once: true, margin: '0px 0px -8% 0px' }}
                  transition={{ duration: 0.7, delay: (i % 3) * 0.08, ease: [0.2, 0.8, 0.2, 1] }}
                  className={`group relative overflow-hidden rounded-2xl border border-gold-400/25 shadow-[0_18px_50px_rgba(0,0,0,0.4)] ${
                    tall ? 'row-span-2' : ''
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => setOpen(i)}
                    aria-label={`Open photo: ${img.alt}`}
                    className="absolute inset-0 h-full w-full"
                  >
                    <img
                      src={asset(img.src)}
                      alt={img.alt}
                      loading="lazy"
                      decoding="async"
                      width={tall ? 800 : 1200}
                      height={tall ? 1000 : 800}
                      className="h-full w-full object-cover transition-transform duration-[1400ms] ease-out group-hover:scale-110"
                    />
                    <span className="absolute inset-0 bg-gradient-to-t from-midnight-950/70 via-transparent to-transparent opacity-70 transition-opacity group-hover:opacity-100" />
                    <span className="absolute bottom-3 right-3 flex h-10 w-10 items-center justify-center rounded-full border border-gold-300/70 bg-midnight-900/60 text-gold-200 opacity-0 backdrop-blur-sm transition-opacity group-hover:opacity-100 group-focus-visible:opacity-100 max-md:opacity-90">
                      <ZoomIn size={18} />
                    </span>
                  </button>
                </motion.li>
              );
            })}
          </AnimatePresence>
        </motion.ul>
      </div>

      <AnimatePresence>
        {open !== null && (
          <Lightbox images={shown} index={open} onClose={() => setOpen(null)} onChange={setOpen} />
        )}
      </AnimatePresence>
    </section>
  );
}
