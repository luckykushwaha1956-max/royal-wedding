import { ExternalLink, MapPin, Navigation } from 'lucide-react';
import weddingConfig from '../config/weddingConfig';
import SectionHeading from '../components/SectionHeading';
import { Reveal } from '../components/Reveal';
import { asset, dateParts, mapsDirectionsUrl, mapsEmbedUrl, mapsSearchUrl } from '../utils/helpers';

const { venue, wedding } = weddingConfig;

export default function Venue() {
  const configured = Boolean(venue.mapQuery.trim() || venue.mapLink.trim());
  const query = venue.mapQuery.trim();
  const directions = venue.mapLink.trim() || (query ? mapsDirectionsUrl(query) : '');
  const openMaps = venue.mapLink.trim() || (query ? mapsSearchUrl(query) : '');
  const d = dateParts(wedding.date);

  return (
    <section id="venue" aria-labelledby="venue-title" className="section">
      <div className="container-x">
        <SectionHeading
          id="venue-title"
          eyebrow="The Venue"
          title="Where the magic happens"
          subtitle="We cannot wait to welcome you. Here is everything you need to find us."
        />

        <div className="mt-14 grid gap-6 lg:grid-cols-[1fr_1.15fr] lg:gap-10">
          {/* details */}
          <Reveal className="glass flex flex-col justify-center rounded-[32px] p-8 sm:p-12">
            <span className="mb-5 flex h-14 w-14 items-center justify-center rounded-full border border-gold-400/50 text-gold-300">
              <MapPin size={24} strokeWidth={1.5} />
            </span>
            <p className="eyebrow !text-[0.7rem]">Wedding Venue</p>
            <h3 className="mt-3 font-serif text-[clamp(2rem,6vw,3rem)] leading-[1.1] text-ivory">{venue.name}</h3>
            <address className="mt-5 not-italic">
              <p className="text-lg leading-relaxed text-pearl/90">{venue.address}</p>
              <p className="mt-1 font-serif text-2xl text-gold-200">{venue.city}</p>
            </address>
            <p className="mt-5 text-sm tracking-[0.15em] text-pearl/70">
              {d.weekday}, {d.day} {d.month} {d.year}
            </p>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              {configured ? (
                <>
                  <a href={directions} target="_blank" rel="noopener noreferrer" className="btn-gold">
                    <Navigation size={17} />
                    Get Directions
                    <span className="sr-only"> (opens Google Maps in a new tab)</span>
                  </a>
                  <a href={openMaps} target="_blank" rel="noopener noreferrer" className="btn-ghost">
                    <ExternalLink size={16} />
                    Open in Maps
                  </a>
                </>
              ) : (
                <button type="button" disabled className="btn-gold">
                  <Navigation size={17} />
                  Directions Coming Soon
                </button>
              )}
            </div>
          </Reveal>

          {/* map */}
          <Reveal delay={0.15} className="glass relative min-h-[320px] overflow-hidden rounded-[32px] lg:min-h-[460px]">
            {configured && query ? (
              <iframe
                title={`Map showing ${venue.name}`}
                src={mapsEmbedUrl(query)}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                allowFullScreen
                className="absolute inset-0 h-full w-full border-0"
                style={{ filter: 'invert(0.92) hue-rotate(180deg) saturate(0.6) brightness(0.95) contrast(0.95)' }}
              />
            ) : (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-8 text-center">
                <MapPin size={34} className="text-gold-300" strokeWidth={1.4} />
                <p className="font-serif text-2xl text-ivory">Map coming soon</p>
                <p className="max-w-xs text-sm text-pearl/75">
                  {configured
                    ? 'Tap “Get Directions” to open the location in Google Maps.'
                    : 'The venue location will appear here once it is confirmed.'}
                </p>
              </div>
            )}
          </Reveal>
        </div>

        {/* venue photographs */}
        <div className="mt-6 grid grid-cols-2 gap-3 sm:gap-6 md:grid-cols-3">
          {venue.photos.map((p, i) => (
            <Reveal
              key={p.src}
              delay={i * 0.1}
              className={`group overflow-hidden rounded-[24px] border border-gold-400/25 shadow-[0_18px_50px_rgba(0,0,0,0.4)] ${
                i === 0 ? 'col-span-2 md:col-span-1' : ''
              }`}
            >
              <div className={`${i === 0 ? 'aspect-[16/9] md:aspect-[4/5]' : 'aspect-[4/5]'} overflow-hidden`}>
                <img
                  src={asset(p.src)}
                  alt={p.alt}
                  loading="lazy"
                  decoding="async"
                  width="900"
                  height="1100"
                  className="h-full w-full object-cover transition-transform duration-[1400ms] ease-out group-hover:scale-110"
                />
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
