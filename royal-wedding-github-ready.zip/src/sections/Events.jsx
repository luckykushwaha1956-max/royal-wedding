import { useRef } from 'react';
import { motion, useReducedMotion, useScroll, useTransform } from 'framer-motion';
import { CalendarDays, Clock, Drum, Flame, Flower2, Hand, MapPin, Music, Navigation, Wine } from 'lucide-react';
import weddingConfig from '../config/weddingConfig';
import SectionHeading from '../components/SectionHeading';
import { Reveal } from '../components/Reveal';
import { Mandala } from '../components/Ornaments';
import { scrollToSection } from '../hooks/useActiveSection';
import { asset, dateParts, mapsSearchUrl } from '../utils/helpers';

const { events, venue } = weddingConfig;

/* Each event has its own identity: icon, colour glow and animated effect. */
const THEMES = {
  petals: { Icon: Flower2, glow: 'rgba(243,227,189,0.35)', accent: '#f3e3bd', tint: 'rgba(243,227,189,0.10)' },
  henna: { Icon: Hand, glow: 'rgba(201,164,92,0.32)', accent: '#dcbf7e', tint: 'rgba(201,164,92,0.10)' },
  sparkle: { Icon: Music, glow: 'rgba(160,170,230,0.32)', accent: '#c9d0f2', tint: 'rgba(120,130,220,0.12)' },
  lamps: { Icon: Drum, glow: 'rgba(232,185,140,0.30)', accent: '#ecd3a8', tint: 'rgba(232,185,140,0.10)' },
  glow: { Icon: Flame, glow: 'rgba(255,230,170,0.38)', accent: '#fff0c7', tint: 'rgba(255,230,170,0.10)' },
  bokeh: { Icon: Wine, glow: 'rgba(232,185,191,0.34)', accent: '#e8b9bf', tint: 'rgba(232,185,191,0.10)' },
};

const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X'];

const seeded = (i, a, b) => {
  const x = Math.sin(i * 91.7 + 17.3) * 43758.5453;
  return a + (x - Math.floor(x)) * (b - a);
};

function EventFx({ theme }) {
  if (theme === 'petals') {
    return Array.from({ length: 10 }, (_, i) => (
      <span
        key={i}
        className="fx-petal"
        style={{
          left: `${seeded(i, 4, 94)}%`,
          '--s': `${seeded(i + 3, 9, 17)}px`,
          '--dur': `${seeded(i + 5, 9, 16)}s`,
          '--dl': `${-seeded(i + 7, 0, 14)}s`,
          '--sway': `${seeded(i + 9, -40, 40)}px`,
          '--c1': i % 3 === 0 ? '#fbeee4' : '#f3e3bd',
          '--c2': i % 3 === 0 ? '#e8b9bf' : '#c9a45c',
        }}
      />
    ));
  }
  if (theme === 'henna') return <span className="fx-henna" />;
  if (theme === 'sparkle') {
    return Array.from({ length: 16 }, (_, i) => (
      <span
        key={i}
        className="fx-spark"
        style={{
          left: `${seeded(i, 4, 96)}%`,
          top: `${seeded(i + 11, 8, 92)}%`,
          '--s': `${seeded(i + 4, 3, 6)}px`,
          '--dur': `${seeded(i + 6, 2.5, 5)}s`,
          '--dl': `${-seeded(i + 8, 0, 5)}s`,
        }}
      />
    ));
  }
  if (theme === 'lamps') {
    return Array.from({ length: 6 }, (_, i) => (
      <span
        key={i}
        className="fx-lamp"
        style={{
          left: `${8 + i * 16.5}%`,
          height: `${seeded(i, 40, 90)}px`,
          '--dur': `${seeded(i + 2, 4, 7)}s`,
          '--dl': `${-seeded(i + 5, 0, 5)}s`,
        }}
      />
    ));
  }
  if (theme === 'glow') return <span className="fx-glow" />;
  if (theme === 'bokeh') {
    return Array.from({ length: 9 }, (_, i) => (
      <span
        key={i}
        className="fx-bokeh"
        style={{
          left: `${seeded(i, 2, 90)}%`,
          top: `${seeded(i + 9, 5, 85)}%`,
          width: seeded(i + 3, 24, 70),
          height: seeded(i + 3, 24, 70),
          '--dur': `${seeded(i + 4, 7, 13)}s`,
          '--dl': `${-seeded(i + 5, 0, 10)}s`,
        }}
      />
    ));
  }
  return null;
}

function locationHref(ev) {
  if (ev.mapLink) return ev.mapLink;
  if (ev.mapQuery) return mapsSearchUrl(ev.mapQuery);
  if (venue.mapLink) return venue.mapLink;
  if (venue.mapQuery) return mapsSearchUrl(venue.mapQuery);
  return null;
}

function EventCard({ ev, index }) {
  const ref = useRef(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] });
  const y = useTransform(scrollYProgress, [0, 1], ['-7%', '7%']);
  const theme = THEMES[ev.theme] || THEMES.glow;
  const { Icon } = theme;
  const d = dateParts(ev.date);
  const href = ev.showLocation ? locationHref(ev) : null;
  const imageLeft = index % 2 === 0;

  return (
    <Reveal
      as="article"
      y={50}
      duration={1.1}
      className="event-card glass relative overflow-hidden rounded-[32px]"
      style={{ '--ev-glow': theme.glow }}
      id={`event-${ev.id}`}
      aria-labelledby={`event-${ev.id}-title`}
    >
      <div ref={ref} className="grid md:grid-cols-2">
        {/* ---------- picture + effect ---------- */}
        <div
          className={`relative aspect-[4/3] overflow-hidden sm:aspect-[16/10] md:aspect-auto md:min-h-[480px] ${
            imageLeft ? 'md:order-1' : 'md:order-2'
          }`}
        >
          <motion.img
            src={asset(ev.image)}
            alt={`${ev.name} — decorative photograph`}
            loading="lazy"
            decoding="async"
            width="1200"
            height="900"
            className="event-img absolute inset-0 h-[114%] w-full object-cover"
            style={reduce ? { top: '-7%' } : { y, top: '-7%' }}
          />
          <div className="absolute inset-0" style={{ background: `linear-gradient(180deg, ${theme.tint}, rgba(4,8,21,0.15) 45%, rgba(4,8,21,0.7))` }} />
          <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
            <EventFx theme={ev.theme} />
          </div>
          <div
            className="absolute left-5 top-5 flex h-14 w-14 items-center justify-center rounded-full border backdrop-blur-md"
            style={{ borderColor: theme.accent, color: theme.accent, background: 'rgba(4,8,21,0.45)', WebkitBackdropFilter: 'blur(8px)' }}
            aria-hidden="true"
          >
            <Icon size={24} strokeWidth={1.5} />
          </div>
          <span
            className="absolute bottom-4 right-6 font-display text-6xl leading-none opacity-40 md:text-7xl"
            style={{ color: theme.accent }}
            aria-hidden="true"
          >
            {ROMAN[index]}
          </span>
        </div>

        {/* ---------- details ---------- */}
        <div className={`relative flex flex-col justify-center p-7 sm:p-10 lg:p-14 ${imageLeft ? 'md:order-2' : 'md:order-1'}`}>
          <Mandala className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 opacity-25" />
          <p className="eyebrow !text-[0.7rem]" style={{ color: theme.accent }}>
            {ev.tagline}
          </p>
          <h3
            id={`event-${ev.id}-title`}
            className="mt-3 font-serif text-[clamp(2rem,6vw,3.1rem)] font-medium leading-[1.1] text-ivory"
          >
            {ev.name}
          </h3>
          <span className="my-5 block h-px w-16" style={{ background: theme.accent }} aria-hidden="true" />

          <dl className="space-y-3.5 text-[1.02rem]">
            <div className="flex items-start gap-3.5">
              <dt className="sr-only">Date</dt>
              <CalendarDays size={20} strokeWidth={1.5} className="mt-1 shrink-0" style={{ color: theme.accent }} aria-hidden="true" />
              <dd className="font-serif text-xl text-ivory">
                {d.weekday}, {d.day} {d.month} {d.year}
              </dd>
            </div>
            <div className="flex items-start gap-3.5">
              <dt className="sr-only">Time</dt>
              <Clock size={20} strokeWidth={1.5} className="mt-1 shrink-0" style={{ color: theme.accent }} aria-hidden="true" />
              <dd className="font-serif text-xl text-ivory">{ev.time}</dd>
            </div>
            <div className="flex items-start gap-3.5">
              <dt className="sr-only">{ev.locationLabel}</dt>
              <MapPin size={20} strokeWidth={1.5} className="mt-1 shrink-0" style={{ color: theme.accent }} aria-hidden="true" />
              <dd className="text-pearl/90">
                <span className="block text-[0.68rem] uppercase tracking-[0.25em] text-pearl/55">{ev.locationLabel}</span>
                <span className="font-serif text-xl text-ivory">{ev.venue}</span>
              </dd>
            </div>
          </dl>

          <p className="mt-6 max-w-lg text-base leading-relaxed text-pearl/85">{ev.description}</p>

          {ev.showLocation && (
            <div className="mt-7">
              {href ? (
                <a href={href} target="_blank" rel="noopener noreferrer" className="btn-ghost">
                  <Navigation size={16} />
                  View Location
                  <span className="sr-only"> (opens Google Maps in a new tab)</span>
                </a>
              ) : (
                <button type="button" disabled className="btn-ghost cursor-not-allowed opacity-60" title="Location will be added soon">
                  <Navigation size={16} />
                  Location Coming Soon
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </Reveal>
  );
}

export default function Events() {
  return (
    <section id="events" aria-labelledby="events-title" className="section">
      <div className="container-x">
        <SectionHeading
          id="events-title"
          eyebrow="The Celebrations"
          title="Join us for every moment"
          subtitle="Six beautiful functions, each with its own colour, music and joy. Tap an event to jump to it."
        />

        <Reveal delay={0.3} className="mx-auto mt-9 flex max-w-3xl flex-wrap justify-center gap-2.5">
          {events.map((ev, i) => (
            <button
              key={ev.id}
              type="button"
              onClick={() => {
                const el = document.getElementById(`event-${ev.id}`);
                el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
              }}
              className="btn-ghost !min-h-11 !px-4 !text-[0.7rem]"
            >
              <span className="font-display text-gold-300">{ROMAN[i]}</span>
              {ev.name.split(' / ')[0].replace(' Ceremony', '')}
            </button>
          ))}
        </Reveal>

        <div className="mt-14 space-y-10 md:mt-20 md:space-y-16">
          {events.map((ev, i) => (
            <EventCard key={ev.id} ev={ev} index={i} />
          ))}
        </div>

        <Reveal className="mt-14 text-center">
          <button type="button" onClick={() => scrollToSection('gallery')} className="btn-ghost">
            See the Gallery
          </button>
        </Reveal>
      </div>
    </section>
  );
}
