import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { CalendarHeart, ChevronDown, MapPin } from 'lucide-react';
import weddingConfig from '../config/weddingConfig';
import { useCountdown } from '../hooks/useCountdown';
import { scrollToSection } from '../hooks/useActiveSection';
import { dateParts, formatTime24 } from '../utils/helpers';
import { GoldDivider } from '../components/Ornaments';

const { couple, wedding, venue, countdown } = weddingConfig;
const TARGET = `${wedding.date}T${wedding.time}:00${wedding.timezoneOffset}`;

function Digit({ value, label }) {
  const reduce = useReducedMotion();
  const text = String(value).padStart(2, '0');
  return (
    <div className="glass flex flex-col items-center rounded-2xl px-2 py-4 sm:px-5 sm:py-6">
      <div className="relative flex h-[1.15em] w-full items-center justify-center overflow-hidden font-display text-[clamp(2rem,9.5vw,3.6rem)] leading-none text-gold-200 tabular-nums">
        <AnimatePresence mode="popLayout" initial={false}>
          <motion.span
            key={text}
            initial={reduce ? false : { y: '70%', opacity: 0, filter: 'blur(4px)' }}
            animate={{ y: '0%', opacity: 1, filter: 'blur(0px)' }}
            exit={reduce ? { opacity: 0 } : { y: '-70%', opacity: 0, filter: 'blur(4px)' }}
            transition={{ duration: 0.4, ease: [0.2, 0.8, 0.2, 1] }}
            className="inline-block"
          >
            {text}
          </motion.span>
        </AnimatePresence>
      </div>
      <span className="mt-2 text-[0.68rem] font-medium uppercase tracking-[0.28em] text-pearl/80 sm:text-xs">
        {label}
      </span>
    </div>
  );
}

export function Countdown() {
  const c = useCountdown(TARGET);

  if (c.done) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass mx-auto max-w-2xl rounded-3xl px-6 py-8 text-center"
        role="status"
      >
        <p className="gold-text font-display text-[clamp(1.6rem,6vw,2.8rem)] tracking-[0.12em]">
          {countdown.finishedMessage}
        </p>
      </motion.div>
    );
  }

  return (
    <div role="timer" aria-label={`Countdown to the wedding: ${c.days} days, ${c.hours} hours, ${c.minutes} minutes, ${c.seconds} seconds`}>
      <p className="eyebrow mb-4 text-center !text-[0.68rem]">{countdown.title}</p>
      <div className="mx-auto grid max-w-2xl grid-cols-4 gap-2 sm:gap-4">
        <Digit value={c.days} label="Days" />
        <Digit value={c.hours} label="Hours" />
        <Digit value={c.minutes} label="Minutes" />
        <Digit value={c.seconds} label="Seconds" />
      </div>
    </div>
  );
}

const rise = (d) => ({
  initial: { opacity: 0, y: 24 },
  animate: { opacity: 1, y: 0 },
  transition: { delay: d, duration: 1, ease: [0.2, 0.8, 0.2, 1] },
});

export default function Home() {
  const p = dateParts(wedding.date);

  return (
    <section
      id="home"
      aria-labelledby="home-title"
      className="relative flex min-h-[100svh] flex-col items-center justify-center px-5 pb-16 pt-24 text-center md:pt-28"
    >
      {/* soft scrim keeps text readable over the palace */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 -z-0"
        style={{ background: 'radial-gradient(ellipse 75% 60% at 50% 55%, rgba(5,9,26,0.62), rgba(5,9,26,0) 75%)' }}
      />
      <motion.p className="eyebrow mb-5" {...rise(0.3)}>
        {couple.inviteLine}
      </motion.p>

      <h1
        id="home-title"
        className="flex flex-col items-center"
        aria-label={`${couple.groom} and ${couple.bride}`}
      >
        <motion.span
          {...rise(0.45)}
          className="gold-text font-display text-[clamp(2.8rem,13vw,6.4rem)] font-medium uppercase leading-[1.02] tracking-[0.1em]"
        >
          {couple.groom}
        </motion.span>
        <motion.span
          aria-hidden="true"
          {...rise(0.6)}
          className="font-script -my-1 text-[clamp(2.2rem,8vw,3.8rem)] text-rose-300"
        >
          and
        </motion.span>
        <motion.span
          {...rise(0.75)}
          className="gold-text font-display text-[clamp(2.8rem,13vw,6.4rem)] font-medium uppercase leading-[1.02] tracking-[0.1em]"
        >
          {couple.bride}
        </motion.span>
      </h1>

      <motion.p
        {...rise(0.95)}
        className="mt-5 font-serif text-[clamp(1.05rem,4.3vw,1.6rem)] uppercase tracking-[0.42em] text-ivory"
      >
        {couple.tagline}
      </motion.p>

      <motion.div {...rise(1.1)} className="mt-7 w-full max-w-xl">
        <GoldDivider />
        <div className="mt-6 flex flex-col items-center gap-3 text-ivory sm:flex-row sm:justify-center sm:gap-8">
          <div className="flex items-center gap-3">
            <CalendarHeart size={20} className="shrink-0 text-gold-300" strokeWidth={1.5} />
            <p className="text-left font-serif text-xl leading-tight sm:text-2xl">
              <span className="block">{p.weekday}, {p.day} {p.month} {p.year}</span>
              <span className="block text-sm tracking-[0.15em] text-pearl/75">{formatTime24(wedding.time)}</span>
            </p>
          </div>
          <span className="hidden h-10 w-px bg-gold-400/40 sm:block" aria-hidden="true" />
          <div className="flex items-center gap-3">
            <MapPin size={20} className="shrink-0 text-gold-300" strokeWidth={1.5} />
            <p className="text-left font-serif text-xl leading-tight sm:text-2xl">
              <span className="block">{venue.name}</span>
              <span className="block text-sm tracking-[0.15em] text-pearl/75">{venue.city}</span>
            </p>
          </div>
        </div>
      </motion.div>

      <motion.p
        {...rise(1.25)}
        className="mx-auto mt-8 max-w-xl text-base leading-relaxed text-pearl/90 sm:text-lg"
      >
        {couple.invitationMessage}
      </motion.p>

      <motion.div {...rise(1.4)} className="mt-9 w-full">
        <Countdown />
      </motion.div>

      <motion.div {...rise(1.6)} className="mt-10">
        <button type="button" onClick={() => scrollToSection('story')} className="btn-gold">
          Explore Invitation
          <ChevronDown size={18} />
        </button>
      </motion.div>
    </section>
  );
}
