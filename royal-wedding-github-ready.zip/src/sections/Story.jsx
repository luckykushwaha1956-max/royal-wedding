import { useEffect, useRef } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import weddingConfig from '../config/weddingConfig';
import SectionHeading from '../components/SectionHeading';
import { Reveal } from '../components/Reveal';
import { Flower } from '../components/Ornaments';
import { asset } from '../utils/helpers';

gsap.registerPlugin(ScrollTrigger);

const { story, couple } = weddingConfig;

function StoryImage({ src, alt, index }) {
  const reduce = useReducedMotion();
  return (
    <motion.div
      className="story-img relative overflow-hidden rounded-[28px] border border-gold-400/30 shadow-[0_30px_80px_rgba(0,0,0,0.5)]"
      initial={reduce ? false : { clipPath: 'inset(0 100% 0 0)' }}
      whileInView={{ clipPath: 'inset(0 0% 0 0)' }}
      viewport={{ once: true, margin: '0px 0px -15% 0px' }}
      transition={{ duration: 1.3, ease: [0.77, 0, 0.175, 1] }}
    >
      <div className="relative aspect-[4/5] w-full overflow-hidden">
        <img
          src={asset(src)}
          alt={alt}
          loading="lazy"
          decoding="async"
          width="800"
          height="1000"
          className="story-parallax absolute left-0 top-[-8%] h-[116%] w-full object-cover"
          data-index={index}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-midnight-950/50 via-transparent to-transparent" />
      </div>
    </motion.div>
  );
}

export default function Story() {
  const root = useRef(null);

  useEffect(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) return undefined;
    const ctx = gsap.context(() => {
      // timeline line draws itself while scrolling
      gsap.fromTo(
        '.tl-line',
        { scaleY: 0 },
        {
          scaleY: 1,
          ease: 'none',
          transformOrigin: 'top center',
          scrollTrigger: { trigger: '.tl-wrap', start: 'top 70%', end: 'bottom 60%', scrub: 0.6 },
        },
      );
      // gentle parallax inside each photo
      gsap.utils.toArray('.story-parallax').forEach((img) => {
        gsap.fromTo(
          img,
          { yPercent: -4 },
          {
            yPercent: 4,
            ease: 'none',
            scrollTrigger: { trigger: img.closest('.story-img'), start: 'top bottom', end: 'bottom top', scrub: true },
          },
        );
      });
      // timeline dots pop
      gsap.utils.toArray('.tl-dot').forEach((dot) => {
        gsap.fromTo(
          dot,
          { scale: 0, opacity: 0 },
          { scale: 1, opacity: 1, duration: 0.6, ease: 'back.out(2)', scrollTrigger: { trigger: dot, start: 'top 80%' } },
        );
      });
    }, root);
    return () => ctx.revert();
  }, []);

  return (
    <section id="story" ref={root} aria-labelledby="story-title" className="section">
      <div className="container-x">
        <SectionHeading
          id="story-title"
          eyebrow={story.eyebrow}
          title={story.heading}
          subtitle={story.intro}
        />

        {/* couple intro */}
        <Reveal className="mx-auto mt-14 flex max-w-2xl flex-col items-center text-center">
          <svg width="64" height="64" viewBox="-32 -32 64 64" aria-hidden="true" className="mb-4">
            <Flower cx={0} cy={0} r={28} id="story-flower" />
          </svg>
          <p className="font-script text-[clamp(2.4rem,9vw,3.8rem)] leading-tight text-gold-200">
            {couple.groom} <span className="text-rose-300">&amp;</span> {couple.bride}
          </p>
        </Reveal>

        {/* timeline */}
        <div className="tl-wrap relative mt-16 md:mt-24">
          <div
            className="absolute bottom-0 left-[14px] top-0 w-px bg-gold-400/15 md:left-1/2 md:-translate-x-1/2"
            aria-hidden="true"
          >
            <div className="tl-line h-full w-full bg-gradient-to-b from-gold-200 via-gold-400 to-gold-500/30" />
          </div>

          <ol className="space-y-16 md:space-y-28">
            {story.milestones.map((m, i) => {
              const left = i % 2 === 0;
              return (
                <li key={m.title} className="relative pl-12 md:pl-0">
                  <span
                    className="tl-dot absolute left-[6px] top-3 flex h-4 w-4 items-center justify-center rounded-full border border-gold-300 bg-midnight-900 md:left-1/2 md:-translate-x-1/2"
                    aria-hidden="true"
                    style={{ boxShadow: '0 0 18px rgba(243,227,189,0.6)' }}
                  >
                    <span className="h-1.5 w-1.5 rounded-full bg-gold-200" />
                  </span>

                  <div className={`grid items-center gap-8 md:grid-cols-2 md:gap-20 ${left ? '' : 'md:[&>*:first-child]:order-2'}`}>
                    <Reveal x={left ? -30 : 30} y={10} className={`${left ? 'md:text-right' : 'md:text-left'}`}>
                      <p className="eyebrow mb-3 !text-[0.7rem]">Chapter {String(i + 1).padStart(2, '0')}</p>
                      <h3 className="font-serif text-[clamp(1.9rem,5.5vw,2.8rem)] leading-tight text-ivory">{m.title}</h3>
                      <p className="mt-4 max-w-md text-base leading-relaxed text-pearl/85 sm:text-lg md:inline-block">
                        {m.text}
                      </p>
                    </Reveal>
                    {m.image && (
                      <div className={`mx-auto w-full max-w-[420px] ${left ? 'md:ml-0' : 'md:mr-0'}`}>
                        <StoryImage src={m.image} alt={`${m.title} — photograph`} index={i} />
                      </div>
                    )}
                  </div>
                </li>
              );
            })}
          </ol>
        </div>
      </div>
    </section>
  );
}
