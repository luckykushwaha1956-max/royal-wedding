import { useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { AlertCircle, Check, Info, Loader2, MessageCircle, Minus, Plus, Send } from 'lucide-react';
import weddingConfig from '../config/weddingConfig';
import SectionHeading from '../components/SectionHeading';
import { Reveal } from '../components/Reveal';
import { formatDate } from '../utils/helpers';

const { rsvp, couple, wedding } = weddingConfig;

const empty = { name: '', phone: '', guests: 1, attending: '', message: '', company: '' };

function validate(v) {
  const e = {};
  const name = v.name.trim();
  if (name.length < 2) e.name = 'Please enter your name (at least 2 letters).';
  else if (name.length > 80) e.name = 'Name is too long (80 letters maximum).';

  const phone = v.phone.trim();
  if (phone) {
    const digits = phone.replace(/[\s\-().+]/g, '');
    if (!/^\d{7,15}$/.test(digits)) e.phone = 'Please enter a valid phone number, or leave it empty.';
  }
  if (!v.attending) e.attending = 'Please tell us if you can attend.';
  if (v.attending === 'yes') {
    const g = Number(v.guests);
    if (!Number.isInteger(g) || g < 1 || g > rsvp.maxGuests) e.guests = `Guests must be between 1 and ${rsvp.maxGuests}.`;
  }
  if (v.message.length > 500) e.message = 'Message is too long (500 characters maximum).';
  return e;
}

function FieldError({ id, children }) {
  if (!children) return null;
  return (
    <p id={id} role="alert" className="mt-2 flex items-center gap-1.5 text-sm text-rose-300">
      <AlertCircle size={15} className="shrink-0" />
      {children}
    </p>
  );
}

export default function Rsvp() {
  const [v, setV] = useState(empty);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle'); // idle | sending | success | error | unconfigured
  const [errorText, setErrorText] = useState('');
  const formRef = useRef(null);

  const set = (k) => (e) => setV((s) => ({ ...s, [k]: e.target.value }));
  const hasBackend = Boolean(rsvp.endpoint.trim());

  const whatsappHref = () => {
    const attend = v.attending === 'yes' ? `I will attend with ${v.guests} guest(s).` : 'I am sorry, I cannot attend.';
    const text = `Hello! This is ${v.name.trim()}. ${attend}${v.message.trim() ? ` ${v.message.trim()}` : ''}`;
    return `https://wa.me/${rsvp.whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(text)}`;
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    if (status === 'sending') return;
    if (v.company) return; // honeypot: real guests never fill this hidden field

    const errs = validate(v);
    setErrors(errs);
    if (Object.keys(errs).length) {
      const first = ['name', 'phone', 'attending', 'guests', 'message'].find((k) => errs[k]);
      formRef.current?.querySelector(`[data-field="${first}"]`)?.focus();
      return;
    }

    if (!hasBackend) {
      setStatus('unconfigured');
      return;
    }

    setStatus('sending');
    setErrorText('');
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 20000);
    try {
      const res = await fetch(rsvp.endpoint.trim(), {
        method: 'POST',
        // text/plain avoids a CORS pre-flight request, which Google Apps Script does not answer
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify({
          name: v.name.trim(),
          phone: v.phone.trim(),
          attending: v.attending === 'yes' ? 'Yes' : 'No',
          guests: v.attending === 'yes' ? Number(v.guests) : 0,
          message: v.message.trim(),
          submittedAt: new Date().toISOString(),
        }),
        signal: ctrl.signal,
      });
      const data = await res.json();
      if (!res.ok || !data || data.ok !== true) throw new Error((data && data.error) || 'Server did not confirm');
      setStatus('success');
    } catch (err) {
      setStatus('error');
      setErrorText(
        err.name === 'AbortError'
          ? 'The request took too long. Please check your internet and try again.'
          : 'We could not confirm that your response was saved. Please try again in a moment.',
      );
    } finally {
      clearTimeout(timer);
    }
  };

  const reset = () => {
    setV(empty);
    setErrors({});
    setStatus('idle');
  };

  const stepGuests = (d) =>
    setV((s) => ({ ...s, guests: Math.min(rsvp.maxGuests, Math.max(1, Number(s.guests) + d)) }));

  return (
    <section id="rsvp" aria-labelledby="rsvp-title" className="section">
      <div className="container-x">
        <SectionHeading id="rsvp-title" eyebrow="RSVP" title={rsvp.heading} subtitle={rsvp.intro} />

        <Reveal className="glass mx-auto mt-12 max-w-2xl rounded-[32px] p-6 sm:p-10">
          <AnimatePresence mode="wait">
            {status === 'success' ? (
              <motion.div
                key="ok"
                initial={{ opacity: 0, scale: 0.94 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="py-8 text-center"
                role="status"
              >
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: 'spring', stiffness: 220, damping: 14, delay: 0.15 }}
                  className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-gold-200 to-gold-500 text-midnight-900"
                  style={{ boxShadow: '0 0 50px rgba(243,227,189,0.45)' }}
                >
                  <Check size={38} strokeWidth={2.2} />
                </motion.span>
                <h3 className="font-serif text-4xl text-ivory">
                  {v.attending === 'yes' ? 'See you there!' : 'Thank you for letting us know'}
                </h3>
                <p className="mx-auto mt-4 max-w-md text-pearl/85">
                  {v.attending === 'yes'
                    ? `Your response is saved, ${v.name.trim()}. We are delighted that you will celebrate with us on ${formatDate(wedding.date)}.`
                    : `Your response is saved, ${v.name.trim()}. You will be missed, and we are grateful for your wishes.`}
                </p>
                <button type="button" onClick={reset} className="btn-ghost mt-8">
                  Send another response
                </button>
              </motion.div>
            ) : (
              <motion.form
                key="form"
                ref={formRef}
                onSubmit={onSubmit}
                noValidate
                exit={{ opacity: 0 }}
                aria-label="RSVP form"
                className="space-y-6"
              >
                {/* honeypot (hidden from people) */}
                <div className="absolute -left-[9999px] h-0 w-0 overflow-hidden" aria-hidden="true">
                  <label>
                    Company
                    <input type="text" tabIndex={-1} autoComplete="off" value={v.company} onChange={set('company')} />
                  </label>
                </div>

                <div>
                  <label htmlFor="rsvp-name" className="mb-2 block text-sm tracking-wide text-pearl">
                    Guest Name <span className="text-rose-300">*</span>
                  </label>
                  <input
                    id="rsvp-name"
                    data-field="name"
                    className="field"
                    type="text"
                    autoComplete="name"
                    placeholder="Your full name"
                    value={v.name}
                    onChange={set('name')}
                    aria-invalid={!!errors.name}
                    aria-describedby={errors.name ? 'err-name' : undefined}
                    maxLength={90}
                  />
                  <FieldError id="err-name">{errors.name}</FieldError>
                </div>

                <div>
                  <label htmlFor="rsvp-phone" className="mb-2 block text-sm tracking-wide text-pearl">
                    Phone Number <span className="text-pearl/50">(optional)</span>
                  </label>
                  <input
                    id="rsvp-phone"
                    data-field="phone"
                    className="field"
                    type="tel"
                    inputMode="tel"
                    autoComplete="tel"
                    placeholder="+91 98765 43210"
                    value={v.phone}
                    onChange={set('phone')}
                    aria-invalid={!!errors.phone}
                    aria-describedby={errors.phone ? 'err-phone' : undefined}
                  />
                  <FieldError id="err-phone">{errors.phone}</FieldError>
                </div>

                <fieldset>
                  <legend className="mb-2 block text-sm tracking-wide text-pearl">
                    Will You Attend? <span className="text-rose-300">*</span>
                  </legend>
                  <div className="grid gap-3 sm:grid-cols-2">
                    {[
                      { val: 'yes', label: 'Joyfully Accept' },
                      { val: 'no', label: 'Regretfully Decline' },
                    ].map((o, i) => (
                      <label key={o.val} className="relative block cursor-pointer">
                        <input
                          type="radio"
                          name="attending"
                          value={o.val}
                          data-field={i === 0 ? 'attending' : undefined}
                          checked={v.attending === o.val}
                          onChange={set('attending')}
                          className="peer absolute inset-0 h-full w-full cursor-pointer opacity-0"
                          aria-describedby={errors.attending ? 'err-attending' : undefined}
                        />
                        <span className="flex min-h-[56px] items-center justify-center rounded-2xl border border-gold-400/30 bg-white/[0.03] px-4 text-center font-serif text-xl text-pearl transition-all peer-checked:border-gold-300 peer-checked:bg-gold-400/20 peer-checked:text-gold-200 peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-gold-300">
                          {o.label}
                        </span>
                      </label>
                    ))}
                  </div>
                  <FieldError id="err-attending">{errors.attending}</FieldError>
                </fieldset>

                <AnimatePresence initial={false}>
                  {v.attending !== 'no' && (
                    <motion.div
                      key="guests"
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="pb-1">
                        <span id="guests-label" className="mb-2 block text-sm tracking-wide text-pearl">
                          Number of Guests (including you)
                        </span>
                        <div role="group" aria-labelledby="guests-label" className="flex items-center gap-4">
                          <button
                            type="button"
                            onClick={() => stepGuests(-1)}
                            aria-label="Decrease number of guests"
                            disabled={Number(v.guests) <= 1}
                            className="btn-ghost !min-h-[54px] !w-[54px] !p-0 disabled:opacity-40"
                          >
                            <Minus size={18} />
                          </button>
                          <output
                            data-field="guests"
                            tabIndex={-1}
                            aria-live="polite"
                            className="w-14 text-center font-display text-4xl text-gold-200"
                          >
                            {v.guests}
                          </output>
                          <button
                            type="button"
                            onClick={() => stepGuests(1)}
                            aria-label="Increase number of guests"
                            disabled={Number(v.guests) >= rsvp.maxGuests}
                            className="btn-ghost !min-h-[54px] !w-[54px] !p-0 disabled:opacity-40"
                          >
                            <Plus size={18} />
                          </button>
                        </div>
                        <FieldError id="err-guests">{errors.guests}</FieldError>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div>
                  <label htmlFor="rsvp-message" className="mb-2 block text-sm tracking-wide text-pearl">
                    Personal Message <span className="text-pearl/50">(optional)</span>
                  </label>
                  <textarea
                    id="rsvp-message"
                    data-field="message"
                    className="field"
                    placeholder={`Write a blessing or a note for ${couple.groom} & ${couple.bride}…`}
                    value={v.message}
                    onChange={set('message')}
                    aria-invalid={!!errors.message}
                    aria-describedby={errors.message ? 'err-message' : undefined}
                    maxLength={600}
                  />
                  <div className="mt-1 text-right text-xs text-pearl/50">{v.message.length}/500</div>
                  <FieldError id="err-message">{errors.message}</FieldError>
                </div>

                {/* honest status messages */}
                <AnimatePresence>
                  {status === 'unconfigured' && (
                    <motion.div
                      key="unconf"
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      role="alert"
                      className="rounded-2xl border border-gold-400/40 bg-gold-400/10 p-4 text-sm text-pearl"
                    >
                      <p className="flex items-start gap-2">
                        <Info size={18} className="mt-0.5 shrink-0 text-gold-300" />
                        <span>
                          <strong className="font-medium text-gold-200">Your response has not been saved.</strong> Online RSVP
                          is not switched on for this invitation yet.
                          {rsvp.whatsapp ? ' You can send your reply on WhatsApp instead:' : ' Please contact the family directly to confirm.'}
                        </span>
                      </p>
                      {rsvp.whatsapp && (
                        <a
                          href={whatsappHref()}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="btn-ghost mt-4 w-full sm:w-auto"
                        >
                          <MessageCircle size={17} />
                          Reply on WhatsApp
                        </a>
                      )}
                    </motion.div>
                  )}
                  {status === 'error' && (
                    <motion.p
                      key="err"
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      role="alert"
                      className="flex items-start gap-2 rounded-2xl border border-rose-400/40 bg-rose-400/10 p-4 text-sm text-rose-300"
                    >
                      <AlertCircle size={18} className="mt-0.5 shrink-0" />
                      {errorText}
                    </motion.p>
                  )}
                </AnimatePresence>

                <button type="submit" disabled={status === 'sending'} className="btn-gold w-full">
                  {status === 'sending' ? (
                    <>
                      <Loader2 size={18} className="animate-spin" />
                      Sending…
                    </>
                  ) : (
                    <>
                      <Send size={17} />
                      Send RSVP
                    </>
                  )}
                </button>
                <p className="text-center text-xs text-pearl/55">{rsvp.deadlineText}</p>
              </motion.form>
            )}
          </AnimatePresence>
        </Reveal>
      </div>
    </section>
  );
}
