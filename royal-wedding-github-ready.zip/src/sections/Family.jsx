import { motion } from 'framer-motion';
import weddingConfig from '../config/weddingConfig';
import SectionHeading from '../components/SectionHeading';
import { Reveal } from '../components/Reveal';
import { Flower, GoldDivider, Mandala } from '../components/Ornaments';

const { family } = weddingConfig;

function FamilyCard({ side, delay, id }) {
  return (
    <Reveal
      delay={delay}
      y={40}
      className="glass relative overflow-hidden rounded-[32px] p-8 text-center sm:p-12"
    >
      <motion.div
        className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 opacity-30"
        animate={{ rotate: 360 }}
        transition={{ duration: 120, repeat: Infinity, ease: 'linear' }}
        aria-hidden="true"
      >
        <Mandala className="h-full w-full" />
      </motion.div>
      <svg width="56" height="56" viewBox="-28 -28 56 56" className="relative mx-auto mb-4" aria-hidden="true">
        <Flower cx={0} cy={0} r={25} id={id} />
      </svg>
      <p className="eyebrow relative !text-[0.7rem]">{side.title}</p>
      <ul className="relative mt-6 space-y-2">
        {side.parents.map((p) => (
          <li key={p} className="font-serif text-[clamp(1.6rem,5vw,2.2rem)] leading-tight text-ivory">
            {p}
          </li>
        ))}
      </ul>
      <p className="relative mt-5 text-sm tracking-[0.12em] text-pearl/70">{side.note}</p>
    </Reveal>
  );
}

export default function Family() {
  return (
    <section id="family" aria-labelledby="family-title" className="section">
      <div className="container-x">
        <SectionHeading id="family-title" eyebrow="Our Families" title={family.heading} />

        <Reveal delay={0.2} className="mx-auto mt-8 max-w-2xl text-center">
          <p className="font-serif text-[clamp(1.25rem,4vw,1.7rem)] italic leading-relaxed text-pearl">{family.message}</p>
        </Reveal>

        <div className="mt-14 grid gap-6 md:grid-cols-2 md:gap-10">
          <FamilyCard side={family.groomSide} delay={0} id="fam-g" />
          <FamilyCard side={family.brideSide} delay={0.15} id="fam-b" />
        </div>

        <Reveal className="mx-auto mt-16 max-w-2xl text-center" delay={0.1}>
          <GoldDivider />
          <p className="eyebrow mt-8 !text-[0.7rem]">Special Blessings</p>
          <p className="mt-4 font-serif text-[clamp(1.4rem,4.6vw,2rem)] italic leading-snug text-gold-200">{family.blessings}</p>
        </Reveal>
      </div>
    </section>
  );
}
