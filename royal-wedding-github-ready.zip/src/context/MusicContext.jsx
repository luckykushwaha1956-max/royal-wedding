import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import weddingConfig from '../config/weddingConfig';
import { asset } from '../utils/helpers';

/* One single <audio> element lives here, at the very top of the app,
   so the music never stops while guests move between sections.

   Audio chain (Web Audio API):
     <audio> -> fadeGain (smooth track changes) -> masterGain (volume/mute)
             -> analyser (real visualizer) -> speakers

   Web Audio is used for volume because iPhone Safari ignores
   audio.volume — this makes the volume slider work on iPhones too.      */

const MusicContext = createContext(null);
export const useMusic = () => useContext(MusicContext);

const { tracks, defaultVolume } = weddingConfig.music;

export function MusicProvider({ children }) {
  const audioRef = useRef(null);
  const ctxRef = useRef(null);
  const fadeRef = useRef(null);
  const masterRef = useRef(null);
  const analyserRef = useRef(null);
  const switchingRef = useRef(false);
  const startedRef = useRef(false);

  const [started, setStarted] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [trackIndex, setTrackIndex] = useState(0);
  const [volume, setVolumeState] = useState(defaultVolume);
  const [muted, setMuted] = useState(false);
  const [missing, setMissing] = useState({}); // trackId -> true when file cannot load
  const [hasAnalyser, setHasAnalyser] = useState(false);

  const volumeRef = useRef(volume);
  const mutedRef = useRef(muted);
  volumeRef.current = volume;
  mutedRef.current = muted;

  /* ----- create the <audio> element once ----- */
  if (!audioRef.current && typeof Audio !== 'undefined') {
    const a = new Audio();
    a.preload = 'auto';
    a.setAttribute('playsinline', '');
    a.loop = false;
    audioRef.current = a;
  }

  const rampGain = (node, value, ms) => {
    const ctx = ctxRef.current;
    if (!ctx || !node) return;
    const t = ctx.currentTime;
    node.gain.cancelScheduledValues(t);
    node.gain.setValueAtTime(node.gain.value, t);
    node.gain.linearRampToValueAtTime(value, t + ms / 1000);
  };

  const applyMaster = useCallback((ms = 120) => {
    const target = mutedRef.current ? 0 : volumeRef.current;
    if (masterRef.current) {
      rampGain(masterRef.current, target, ms);
    } else if (audioRef.current) {
      audioRef.current.volume = target; // fallback (not honoured on iPhone)
    }
  }, []);

  const wait = (ms) => new Promise((r) => setTimeout(r, ms));

  /* ----- must be called from a click/tap ----- */
  const ensureContext = useCallback(() => {
    const audio = audioRef.current;
    if (!audio || ctxRef.current) {
      if (ctxRef.current?.state === 'suspended' || ctxRef.current?.state === 'interrupted') {
        ctxRef.current.resume().catch(() => {});
      }
      return;
    }
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      const ctx = new AC();
      const src = ctx.createMediaElementSource(audio);
      const fade = ctx.createGain();
      const master = ctx.createGain();
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 128;
      analyser.smoothingTimeConstant = 0.82;
      src.connect(fade);
      fade.connect(master);
      master.connect(analyser);
      analyser.connect(ctx.destination);
      fade.gain.value = 0;
      master.gain.value = mutedRef.current ? 0 : volumeRef.current;
      ctxRef.current = ctx;
      fadeRef.current = fade;
      masterRef.current = master;
      analyserRef.current = analyser;
      setHasAnalyser(true);
      ctx.resume().catch(() => {});
    } catch {
      /* Web Audio unavailable: plain <audio> still works */
    }
  }, []);

  const fadeIn = useCallback((ms = 700) => {
    if (fadeRef.current) rampGain(fadeRef.current, 1, ms);
  }, []);
  const fadeOut = useCallback((ms = 350) => {
    if (fadeRef.current) rampGain(fadeRef.current, 0, ms);
  }, []);

  const loadTrack = useCallback((index) => {
    const audio = audioRef.current;
    const track = tracks[index];
    if (!audio || !track) return;
    audio.src = asset(track.src);
    audio.load();
  }, []);

  const tryPlay = useCallback(async () => {
    const audio = audioRef.current;
    if (!audio) return false;
    if (ctxRef.current && ctxRef.current.state !== 'running') {
      try {
        await ctxRef.current.resume();
      } catch {
        /* ignore */
      }
    }
    try {
      await audio.play();
      return true;
    } catch {
      return false;
    }
  }, []);

  /* ----- public actions ----- */
  const start = useCallback(async () => {
    if (!tracks.length) return;
    ensureContext();
    startedRef.current = true;
    setStarted(true);
    const audio = audioRef.current;
    if (!audio.src) loadTrack(trackIndex);
    if (!fadeRef.current) audio.volume = mutedRef.current ? 0 : volumeRef.current;
    applyMaster(0);
    const ok = await tryPlay();
    if (ok) fadeIn(1400);
  }, [applyMaster, ensureContext, fadeIn, loadTrack, trackIndex, tryPlay]);

  const play = useCallback(async () => {
    ensureContext();
    const audio = audioRef.current;
    if (!audio.src) loadTrack(trackIndex);
    startedRef.current = true;
    setStarted(true);
    const ok = await tryPlay();
    if (ok) fadeIn(600);
  }, [ensureContext, fadeIn, loadTrack, trackIndex, tryPlay]);

  const pause = useCallback(async () => {
    const audio = audioRef.current;
    if (!audio) return;
    fadeOut(300);
    await wait(fadeRef.current ? 320 : 0);
    audio.pause();
  }, [fadeOut]);

  const toggle = useCallback(() => {
    const audio = audioRef.current;
    if (audio && !audio.paused) pause();
    else play();
  }, [pause, play]);

  const selectTrack = useCallback(
    async (index) => {
      const n = ((index % tracks.length) + tracks.length) % tracks.length;
      const audio = audioRef.current;
      if (!audio || switchingRef.current) return;
      switchingRef.current = true;
      const wasPlaying = !audio.paused || !startedRef.current;
      ensureContext();
      if (!audio.paused) {
        fadeOut(350);
        await wait(fadeRef.current ? 380 : 0);
      }
      setTrackIndex(n);
      loadTrack(n);
      startedRef.current = true;
      setStarted(true);
      if (wasPlaying || true) {
        const ok = await tryPlay();
        if (ok) fadeIn(800);
      }
      switchingRef.current = false;
    },
    [ensureContext, fadeIn, fadeOut, loadTrack, tryPlay],
  );

  const next = useCallback(() => selectTrack(trackIndex + 1), [selectTrack, trackIndex]);
  const prev = useCallback(() => selectTrack(trackIndex - 1), [selectTrack, trackIndex]);

  const setVolume = useCallback(
    (v) => {
      volumeRef.current = v;
      setVolumeState(v);
      if (v > 0 && mutedRef.current) {
        mutedRef.current = false;
        setMuted(false);
      }
      applyMaster(80);
    },
    [applyMaster],
  );

  const toggleMute = useCallback(() => {
    mutedRef.current = !mutedRef.current;
    setMuted(mutedRef.current);
    applyMaster(150);
  }, [applyMaster]);

  /* ----- audio element events ----- */
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return undefined;
    const onPlaying = () => {
      setPlaying(true);
      setMissing((m) => (m[tracks[trackIndex]?.id] ? { ...m, [tracks[trackIndex].id]: false } : m));
    };
    const onPause = () => setPlaying(false);
    const onEnded = () => {
      const n = (trackIndex + 1) % tracks.length;
      setTrackIndex(n);
      loadTrack(n);
      tryPlay().then((ok) => ok && fadeIn(800));
    };
    const onError = () => {
      setPlaying(false);
      const id = tracks[trackIndex]?.id;
      if (id) setMissing((m) => ({ ...m, [id]: true }));
    };
    audio.addEventListener('playing', onPlaying);
    audio.addEventListener('pause', onPause);
    audio.addEventListener('ended', onEnded);
    audio.addEventListener('error', onError);
    return () => {
      audio.removeEventListener('playing', onPlaying);
      audio.removeEventListener('pause', onPause);
      audio.removeEventListener('ended', onEnded);
      audio.removeEventListener('error', onError);
    };
  }, [fadeIn, loadTrack, trackIndex, tryPlay]);

  /* ----- lock-screen / headphone controls ----- */
  useEffect(() => {
    if (!('mediaSession' in navigator) || !started) return;
    const t = tracks[trackIndex];
    try {
      navigator.mediaSession.metadata = new window.MediaMetadata({
        title: t?.title || 'Wedding Music',
        artist: `${weddingConfig.couple.groom} & ${weddingConfig.couple.bride}`,
        album: 'Wedding Invitation',
      });
      navigator.mediaSession.setActionHandler('play', () => play());
      navigator.mediaSession.setActionHandler('pause', () => pause());
      navigator.mediaSession.setActionHandler('nexttrack', () => next());
      navigator.mediaSession.setActionHandler('previoustrack', () => prev());
    } catch {
      /* not supported */
    }
  }, [started, trackIndex, play, pause, next, prev]);

  const value = useMemo(
    () => ({
      tracks,
      track: tracks[trackIndex],
      trackIndex,
      started,
      playing,
      volume,
      muted,
      missing,
      trackMissing: !!missing[tracks[trackIndex]?.id],
      hasAnalyser,
      analyserRef,
      start,
      play,
      pause,
      toggle,
      next,
      prev,
      selectTrack,
      setVolume,
      toggleMute,
    }),
    [
      trackIndex,
      started,
      playing,
      volume,
      muted,
      missing,
      hasAnalyser,
      start,
      play,
      pause,
      toggle,
      next,
      prev,
      selectTrack,
      setVolume,
      toggleMute,
    ],
  );

  return <MusicContext.Provider value={value}>{children}</MusicContext.Provider>;
}
