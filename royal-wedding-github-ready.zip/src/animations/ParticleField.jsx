import { useEffect, useRef } from 'react';
import { prefersReducedMotion } from '../utils/helpers';

/* Canvas particles: rose petals + golden dust.
   - Pre-rendered sprites (fast)
   - Smaller counts and lower resolution on phones
   - Pauses automatically when the tab is hidden                          */

function makePetalSprite(c1, c2) {
  const w = 44;
  const h = 62;
  const cv = document.createElement('canvas');
  cv.width = w;
  cv.height = h;
  const g = cv.getContext('2d');
  const grad = g.createLinearGradient(0, 0, w, h);
  grad.addColorStop(0, c1);
  grad.addColorStop(1, c2);
  g.fillStyle = grad;
  g.beginPath();
  g.moveTo(w / 2, 2);
  g.bezierCurveTo(w + 4, h * 0.2, w * 0.95, h * 0.85, w / 2, h - 2);
  g.bezierCurveTo(w * 0.05, h * 0.85, -4, h * 0.2, w / 2, 2);
  g.fill();
  g.strokeStyle = 'rgba(255,255,255,0.28)';
  g.lineWidth = 1;
  g.beginPath();
  g.moveTo(w / 2, 6);
  g.quadraticCurveTo(w / 2 + 2, h / 2, w / 2, h - 8);
  g.stroke();
  return cv;
}

function makeDotSprite() {
  const s = 48;
  const cv = document.createElement('canvas');
  cv.width = s;
  cv.height = s;
  const g = cv.getContext('2d');
  const grad = g.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
  grad.addColorStop(0, 'rgba(255,246,214,1)');
  grad.addColorStop(0.25, 'rgba(243,227,189,0.75)');
  grad.addColorStop(1, 'rgba(220,191,126,0)');
  g.fillStyle = grad;
  g.fillRect(0, 0, s, s);
  return cv;
}

const rnd = (a, b) => a + Math.random() * (b - a);

export default function ParticleField({ petals = 26, dust = 60, className = '' }) {
  const ref = useRef(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return undefined;
    const ctx = canvas.getContext('2d');
    const reduce = prefersReducedMotion();
    const small = window.innerWidth < 768;
    const dprCap = small ? 1.25 : 1.75;

    const sprites = {
      rose: makePetalSprite('#f1c7cd', '#c47a88'),
      blush: makePetalSprite('#fbeee4', '#e8b9bf'),
      gold: makePetalSprite('#f3e3bd', '#b8933f'),
      dot: makeDotSprite(),
    };
    const petalKinds = ['rose', 'rose', 'blush', 'gold'];

    let w = 0;
    let h = 0;
    let dpr = 1;
    let petalList = [];
    let dustList = [];
    let raf = 0;
    let last = 0;
    let running = true;

    const nPetals = small ? Math.round(petals * 0.45) : petals;
    const nDust = small ? Math.round(dust * 0.45) : dust;

    const newPetal = (initial) => ({
      x: rnd(0, w),
      y: initial ? rnd(-h * 0.1, h) : rnd(-80, -20),
      size: rnd(0.28, 0.62) * (small ? 0.85 : 1),
      vy: rnd(18, 44),
      sway: rnd(14, 46),
      freq: rnd(0.5, 1.3),
      phase: rnd(0, Math.PI * 2),
      rot: rnd(0, Math.PI * 2),
      spin: rnd(-0.8, 0.8),
      flip: rnd(0, Math.PI * 2),
      flipSpeed: rnd(0.8, 2.2),
      alpha: rnd(0.4, 0.85),
      kind: sprites[petalKinds[Math.floor(Math.random() * petalKinds.length)]],
      drift: rnd(-6, 10),
    });

    const newDust = (initial) => ({
      x: rnd(0, w),
      y: initial ? rnd(0, h) : h + rnd(10, 60),
      size: rnd(0.12, 0.42),
      vy: rnd(-16, -5),
      sway: rnd(6, 20),
      freq: rnd(0.3, 0.9),
      phase: rnd(0, Math.PI * 2),
      tw: rnd(0.6, 1.8),
      twp: rnd(0, Math.PI * 2),
      alpha: rnd(0.25, 0.9),
    });

    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, dprCap);
      w = canvas.clientWidth;
      h = canvas.clientHeight;
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const draw = (t) => {
      ctx.clearRect(0, 0, w, h);
      for (const d of dustList) {
        const a = d.alpha * (0.55 + 0.45 * Math.sin(t * d.tw + d.twp));
        const s = d.size * 48;
        ctx.globalAlpha = Math.max(0, a);
        ctx.drawImage(sprites.dot, d.x - s / 2, d.y - s / 2, s, s);
      }
      for (const p of petalList) {
        const fx = Math.cos(p.flip);
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.scale(Math.max(0.25, Math.abs(fx)), 1);
        ctx.globalAlpha = p.alpha;
        const pw = 44 * p.size;
        const ph = 62 * p.size;
        ctx.drawImage(p.kind, -pw / 2, -ph / 2, pw, ph);
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.globalAlpha = 1;
    };

    const step = (now) => {
      if (!running) return;
      const dt = Math.min(0.05, (now - last) / 1000 || 0.016);
      last = now;
      const t = now / 1000;

      for (const p of petalList) {
        p.y += p.vy * dt;
        p.x += (Math.sin(t * p.freq + p.phase) * p.sway + p.drift) * dt;
        p.rot += p.spin * dt;
        p.flip += p.flipSpeed * dt;
        if (p.y > h + 40 || p.x < -60 || p.x > w + 60) Object.assign(p, newPetal(false), { x: rnd(0, w) });
      }
      for (const d of dustList) {
        d.y += d.vy * dt;
        d.x += Math.sin(t * d.freq + d.phase) * d.sway * dt;
        if (d.y < -30) Object.assign(d, newDust(false));
      }
      draw(t);
      raf = requestAnimationFrame(step);
    };

    const onVisibility = () => {
      if (document.hidden) {
        running = false;
        cancelAnimationFrame(raf);
      } else if (!running && !reduce) {
        running = true;
        last = performance.now();
        raf = requestAnimationFrame(step);
      }
    };

    resize();
    petalList = Array.from({ length: nPetals }, () => newPetal(true));
    dustList = Array.from({ length: nDust }, () => newDust(true));

    if (reduce) {
      draw(0);
    } else {
      last = performance.now();
      raf = requestAnimationFrame(step);
    }

    let resizeTimer;
    const onResize = () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => {
        resize();
        if (reduce) draw(0);
      }, 150);
    };
    window.addEventListener('resize', onResize);
    document.addEventListener('visibilitychange', onVisibility);

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      clearTimeout(resizeTimer);
      window.removeEventListener('resize', onResize);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, [petals, dust]);

  return <canvas ref={ref} className={className || 'cine-canvas'} aria-hidden="true" />;
}
