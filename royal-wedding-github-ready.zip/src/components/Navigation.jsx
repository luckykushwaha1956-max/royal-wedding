import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  CalendarDays,
  Heart,
  Home,
  Images,
  MailCheck,
  MapPin,
  MoreHorizontal,
  Phone,
  Share2,
  Users,
  X,
} from 'lucide-react';
import weddingConfig from '../config/weddingConfig';
import { scrollToSection, useActiveSection } from '../hooks/useActiveSection';
import { shareInvitation } from '../utils/share';

const ICONS = {
  home: Home,
  story: Heart,
  events: CalendarDays,
  gallery: Images,
  venue: MapPin,
  more: MoreHorizontal,
};

const MORE_IDS = ['rsvp', 'family', 'contact'];
const ALL_IDS = ['home', 'story', 'events', 'gallery', 'venue', 'rsvp', 'family', 'contact'];

const MORE_ITEMS = [
  { id: 'rsvp', label: 'RSVP', hint: 'Let us know you are coming', Icon: MailCheck },
  { id: 'family', label: 'Family', hint: 'Blessings & invitations', Icon: Users },
  { id: 'contact', label: 'Contact', hint: 'Reach out to the family', Icon: Phone },
];

/* ------------------------------ MORE SHEET ------------------------------ */
function MoreSheet({ open, onClose, onGo }) {
  const first = useRef(null);
  const [toast, setToast] = useState('');

  useEffect(() => {
    if (!open) return undefined;
    const t = setTimeout(() => first.current?.focus(), 80);
    const onKey = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => {
      clearTimeout(t);
      window.removeEventListener('keydown', onKey);
    };
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[70] md:hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
        >
          <button
            type="button"
            aria-label="Close menu"
            className="absolute inset-0 bg-black/55"
            style={{ WebkitBackdropFilter: 'blur(3px)', backdropFilter: 'blur(3px)' }}
            onClick={onClose}
          />
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label="More sections"
            className="glass-strong absolute inset-x-0 bottom-0 rounded-t-[28px] px-5 pt-3"
            style={{ paddingBottom: 'calc(var(--sab) + 24px)' }}
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 320 }}
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0, bottom: 0.5 }}
            onDragEnd={(_, info) => info.offset.y > 90 && onClose()}
          >
            <div className="mx-auto mb-4 h-1.5 w-12 rounded-full bg-white/25" aria-hidden="true" />
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-serif text-2xl text-ivory">More</h2>
              <button
                type="button"
                onClick={onClose}
                aria-label="Close"
                className="flex h-11 w-11 items-center justify-center rounded-full text-pearl/80 hover:bg-white/10"
              >
                <X size={20} />
              </button>
            </div>
            <ul className="space-y-2">
              {MORE_ITEMS.map(({ id, label, hint, Icon }, i) => (
                <li key={id}>
                  <button
                    ref={i === 0 ? first : undefined}
                    type="button"
                    onClick={() => onGo(id)}
                    className="flex min-h-[64px] w-full items-center gap-4 rounded-2xl border border-gold-400/20 bg-white/[0.03] px-4 text-left active:bg-gold-400/10"
                  >
                    <span className="flex h-11 w-11 items-center justify-center rounded-full bg-gold-400/15 text-gold-300">
                      <Icon size={20} strokeWidth={1.6} />
                    </span>
                    <span>
                      <span className="block font-serif text-xl leading-tight text-ivory">{label}</span>
                      <span className="block text-xs text-pearl/70">{hint}</span>
                    </span>
                  </button>
                </li>
              ))}
              <li>
                <button
                  type="button"
                  onClick={async () => {
                    const r = await shareInvitation();
                    if (r === 'copied') {
                      setToast('Link copied');
                      setTimeout(() => setToast(''), 2200);
                    }
                  }}
                  className="flex min-h-[64px] w-full items-center gap-4 rounded-2xl border border-gold-400/20 bg-white/[0.03] px-4 text-left active:bg-gold-400/10"
                >
                  <span className="flex h-11 w-11 items-center justify-center rounded-full bg-gold-400/15 text-gold-300">
                    <Share2 size={20} strokeWidth={1.6} />
                  </span>
                  <span>
                    <span className="block font-serif text-xl leading-tight text-ivory">Share invitation</span>
                    <span className="block text-xs text-pearl/70" aria-live="polite">
                      {toast || 'Send it to family and friends'}
                    </span>
                  </span>
                </button>
              </li>
            </ul>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ------------------------------ BOTTOM NAV ------------------------------ */
export function BottomNav() {
  const active = useActiveSection(ALL_IDS);
  const [moreOpen, setMoreOpen] = useState(false);
  const current = MORE_IDS.includes(active) ? 'more' : active;

  const go = (id) => {
    if (id === 'more') {
      setMoreOpen(true);
      return;
    }
    scrollToSection(id);
  };

  return (
    <>
      <nav
        aria-label="Main navigation"
        className="glass-strong fixed inset-x-0 bottom-0 z-[65] md:hidden"
        style={{
          paddingBottom: 'var(--sab)',
          paddingLeft: 'var(--sal)',
          paddingRight: 'var(--sar)',
          borderRadius: '22px 22px 0 0',
          borderBottom: 'none',
        }}
      >
        <ul className="mx-auto flex h-[var(--nav-h)] max-w-[520px] items-stretch justify-between px-2">
          {weddingConfig.nav.map(({ id, label }) => {
            const Icon = ICONS[id] || Home;
            const isActive = current === id;
            return (
              <li key={id} className="flex-1">
                <button
                  type="button"
                  onClick={() => go(id)}
                  aria-label={label}
                  aria-current={isActive ? 'page' : undefined}
                  aria-haspopup={id === 'more' ? 'dialog' : undefined}
                  className={`relative flex h-full w-full flex-col items-center justify-center gap-1 transition-colors ${
                    isActive ? 'text-gold-200' : 'text-pearl/65'
                  }`}
                >
                  {isActive && (
                    <motion.span
                      layoutId="nav-active"
                      className="absolute left-1/2 top-1.5 h-[3px] w-8 -translate-x-1/2 rounded-full bg-gradient-to-r from-gold-500 via-gold-200 to-gold-500"
                      style={{ boxShadow: '0 0 12px rgba(243,227,189,0.8)' }}
                      transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                    />
                  )}
                  <motion.span animate={{ y: isActive ? -1 : 0, scale: isActive ? 1.12 : 1 }} transition={{ duration: 0.25 }}>
                    <Icon size={22} strokeWidth={isActive ? 1.9 : 1.5} />
                  </motion.span>
                  <span className="text-[0.7rem] font-medium uppercase leading-none tracking-[0.12em]">{label}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>
      <MoreSheet
        open={moreOpen}
        onClose={() => setMoreOpen(false)}
        onGo={(id) => {
          setMoreOpen(false);
          setTimeout(() => scrollToSection(id), 220);
        }}
      />
    </>
  );
}

/* ------------------------------- TOP NAV (desktop) ------------------------------- */
const TOP_ITEMS = [
  { id: 'home', label: 'Home' },
  { id: 'story', label: 'Story' },
  { id: 'events', label: 'Events' },
  { id: 'gallery', label: 'Gallery' },
  { id: 'venue', label: 'Venue' },
  { id: 'rsvp', label: 'RSVP' },
  { id: 'family', label: 'Family' },
  { id: 'contact', label: 'Contact' },
];

export function TopNav() {
  const active = useActiveSection(ALL_IDS);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 40);
    on();
    window.addEventListener('scroll', on, { passive: true });
    return () => window.removeEventListener('scroll', on);
  }, []);

  return (
    <motion.nav
      aria-label="Main navigation"
      className="pointer-events-none fixed inset-x-0 z-[65] hidden justify-center md:flex"
      style={{ top: 18 }}
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.6, duration: 0.8 }}
    >
      <ul
        className={`pointer-events-auto flex max-w-[96vw] items-center gap-0.5 rounded-full px-2 py-1.5 transition-all duration-500 lg:gap-1 ${
          scrolled ? 'glass-strong' : 'glass'
        }`}
      >
        {TOP_ITEMS.map(({ id, label }) => {
          const isActive = active === id;
          return (
            <li key={id}>
              <button
                type="button"
                onClick={() => scrollToSection(id)}
                aria-current={isActive ? 'page' : undefined}
                className={`relative min-h-11 rounded-full px-3 text-[0.72rem] font-medium uppercase tracking-[0.16em] lg:px-4 lg:text-[0.74rem] lg:tracking-[0.18em] transition-colors ${
                  isActive ? 'text-midnight-900' : 'text-pearl/80 hover:text-gold-200'
                }`}
              >
                {isActive && (
                  <motion.span
                    layoutId="top-active"
                    className="absolute inset-0 rounded-full bg-gradient-to-br from-gold-200 via-gold-400 to-gold-500"
                    transition={{ type: 'spring', stiffness: 380, damping: 32 }}
                  />
                )}
                <span className="relative">{label}</span>
              </button>
            </li>
          );
        })}
      </ul>
    </motion.nav>
  );
}
