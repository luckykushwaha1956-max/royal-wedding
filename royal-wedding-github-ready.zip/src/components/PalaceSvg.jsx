import { memo } from 'react';

/* A night-time palace with a lit wedding mandap in its central arch.
   Drawn entirely in code (no image files) so it can be animated. */

const dome = (cx, baseY, r, h) =>
  `M${cx - r} ${baseY} C${cx - r * 1.18} ${baseY - h * 0.45} ${cx - r * 0.5} ${baseY - h * 0.82} ${cx} ${baseY - h} C${cx + r * 0.5} ${baseY - h * 0.82} ${cx + r * 1.18} ${baseY - h * 0.45} ${cx + r} ${baseY} Z`;

const arch = (cx, top, w, bot) =>
  `M${cx - w / 2} ${bot} V${top + w * 0.85} Q${cx - w / 2} ${top + w * 0.3} ${cx} ${top} Q${cx + w / 2} ${top + w * 0.3} ${cx + w / 2} ${top + w * 0.85} V${bot} Z`;

const range = (n) => Array.from({ length: n }, (_, i) => i);

function Finial({ x, y, h = 34 }) {
  return (
    <g>
      <rect x={x - 1.4} y={y - h} width="2.8" height={h} />
      <circle cx={x} cy={y - h} r="4.2" />
      <circle cx={x} cy={y - h * 0.55} r="3" />
    </g>
  );
}

function Minaret({ x, top = 210, bottom = 570 }) {
  return (
    <g>
      <rect x={x - 13} y={top + 70} width="26" height={bottom - top - 70} />
      <rect x={x - 19} y={top + 62} width="38" height="9" rx="2" />
      <rect x={x - 11} y={top + 24} width="22" height="40" />
      <rect x={x - 16} y={top + 18} width="32" height="7" rx="2" />
      <path d={dome(x, top + 18, 15, 34)} />
      <Finial x={x} y={top - 16} h={26} />
    </g>
  );
}

function Chhatri({ x, y }) {
  return (
    <g>
      <rect x={x - 17} y={y} width="34" height="5" />
      {[-13, -4, 5, 12].map((dx) => (
        <rect key={dx} x={x + dx - 1.5} y={y + 5} width="3" height="18" />
      ))}
      <path d={dome(x, y, 19, 26)} />
      <Finial x={x} y={y - 26} h={14} />
    </g>
  );
}

function Silhouette({ animate }) {
  const winCls = animate ? 'win' : '';
  return (
    <>
      <defs>
        <linearGradient id="pal-warm" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#fff3d0" />
          <stop offset="45%" stopColor="#e9d19a" />
          <stop offset="100%" stopColor="#8a6a2c" />
        </linearGradient>
        <linearGradient id="pal-far" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#16224a" />
          <stop offset="100%" stopColor="#0b1331" />
        </linearGradient>
        <linearGradient id="pal-near" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#0a1230" />
          <stop offset="100%" stopColor="#040712" />
        </linearGradient>
        <radialGradient id="pal-halo" cx="50%" cy="60%" r="50%">
          <stop offset="0%" stopColor="#f3e3bd" stopOpacity="0.55" />
          <stop offset="100%" stopColor="#f3e3bd" stopOpacity="0" />
        </radialGradient>
      </defs>

      {/* soft halo behind the central hall */}
      <ellipse cx="800" cy="420" rx="420" ry="230" fill="url(#pal-halo)" />

      {/* FAR LAYER (hazy distant wings) */}
      <g fill="url(#pal-far)" stroke="rgba(243,227,189,0.10)" strokeWidth="1">
        <rect x="0" y="400" width="640" height="170" />
        <rect x="960" y="400" width="640" height="170" />
        {range(8).map((i) => (
          <path key={`fl${i}`} d={dome(40 + i * 78, 400, 26, 36)} />
        ))}
        {range(8).map((i) => (
          <path key={`fr${i}`} d={dome(1560 - i * 78, 400, 26, 36)} />
        ))}
        <Minaret x={150} top={250} />
        <Minaret x={1450} top={250} />
      </g>

      {/* NEAR LAYER */}
      <g fill="url(#pal-near)" stroke="rgba(243,227,189,0.16)" strokeWidth="1.2">
        {/* outer wings */}
        <rect x="0" y="445" width="470" height="130" />
        <rect x="1130" y="445" width="470" height="130" />
        {/* side blocks */}
        <rect x="420" y="360" width="150" height="215" />
        <rect x="1030" y="360" width="150" height="215" />
        <path d={dome(495, 360, 52, 74)} />
        <path d={dome(1105, 360, 52, 74)} />
        <Finial x={495} y={286} h={28} />
        <Finial x={1105} y={286} h={28} />
        {/* main hall */}
        <rect x="560" y="318" width="480" height="260" />
        <path d={dome(800, 318, 118, 168)} />
        <Finial x={800} y={150} h={52} />
        {/* tiny corner chhatris */}
        <Chhatri x={585} y={304} />
        <Chhatri x={1015} y={304} />
        <Chhatri x={250} y={430} />
        <Chhatri x={1350} y={430} />
        <Chhatri x={90} y={430} />
        <Chhatri x={1510} y={430} />
        <Minaret x={398} top={215} />
        <Minaret x={1202} top={215} />
        {/* ground */}
        <rect x="0" y="548" width="1600" height="30" fill="#03060f" />
      </g>

      {/* LIT WINDOWS */}
      <g fill="url(#pal-warm)" className={winCls}>
        {range(11).map((i) => (
          <path
            key={`wa${i}`}
            d={arch(595 + i * 41, 352, 16, 392)}
            className={animate ? 'win' : undefined}
            style={{ '--dl': `${(i * 0.37) % 4}s`, '--d': `${4 + (i % 4)}s` }}
          />
        ))}
        {range(10).map((i) => (
          <path
            key={`wb${i}`}
            d={arch(450 + i * 18, 420, 11, 452)}
            className={animate ? 'win' : undefined}
            style={{ '--dl': `${(i * 0.6) % 5}s`, '--d': `${5 + (i % 3)}s` }}
          />
        ))}
        {range(10).map((i) => (
          <path
            key={`wc${i}`}
            d={arch(1050 + i * 18, 420, 11, 452)}
            className={animate ? 'win' : undefined}
            style={{ '--dl': `${(i * 0.5) % 5}s`, '--d': `${5 + (i % 3)}s` }}
          />
        ))}
        {range(14).map((i) => (
          <path
            key={`wd${i}`}
            d={arch(22 + i * 32, 476, 12, 512)}
            className={animate ? 'win' : undefined}
            style={{ '--dl': `${(i * 0.45) % 5}s`, '--d': `${4 + (i % 5)}s` }}
          />
        ))}
        {range(14).map((i) => (
          <path
            key={`we${i}`}
            d={arch(1146 + i * 32, 476, 12, 512)}
            className={animate ? 'win' : undefined}
            style={{ '--dl': `${(i * 0.52) % 5}s`, '--d': `${4 + (i % 5)}s` }}
          />
        ))}
        {/* tiny minaret lights */}
        {[398, 1202].map((x) => (
          <rect key={x} x={x - 2.5} y={330} width="5" height="14" rx="2" />
        ))}
      </g>

      {/* CENTRAL ARCH WITH THE MANDAP */}
      <path d={arch(800, 360, 200, 560)} fill="url(#pal-warm)" opacity="0.95" />
      <g fill="#050a19">
        {/* canopy */}
        <path d={dome(800, 452, 62, 44)} />
        <rect x="738" y="450" width="124" height="6" />
        {range(13).map((i) => (
          <path key={`fr${i}`} d={`M${742 + i * 9.5} 456 q4.7 11 9.5 0 z`} />
        ))}
        {/* pillars */}
        {[744, 774, 826, 856].map((x) => (
          <rect key={x} x={x - 3} y={456} width="6" height="72" />
        ))}
        {/* platform */}
        <rect x="722" y="528" width="156" height="12" />
        <rect x="710" y="540" width="180" height="20" />
      </g>
      {/* sacred flame in the mandap */}
      <g className={animate ? 'flame' : undefined}>
        <path d="M800 488 q-9 11 0 24 q9 -13 0 -24 z" fill="#fff3d0" />
        <circle cx="800" cy="506" r="14" fill="#fff3d0" opacity="0.28" />
      </g>
      {/* marigold garlands on pillars */}
      {[744, 774, 826, 856].map((x, i) => (
        <g key={x} fill="#dcbf7e" opacity="0.9">
          {range(5).map((j) => (
            <circle key={j} cx={x + (j % 2 ? 2 : -2)} cy={470 + j * 10} r="2.4" />
          ))}
          <circle cx={x} cy={470} r="0" />
          {i === 9 && null}
        </g>
      ))}

      {/* FAIRY LIGHTS along the facade */}
      <g fill="#fff3d0">
        {range(26).map((i) => {
          const x = 562 + i * 19;
          const y = 336 + Math.sin(i * 0.85) * 3 + (i % 2 ? 5 : 0);
          return (
            <circle
              key={i}
              cx={x}
              cy={y}
              r="2.1"
              className={animate ? 'win' : undefined}
              style={{ '--dl': `${(i * 0.23) % 3}s`, '--d': `${2.4 + (i % 3) * 0.6}s` }}
            />
          );
        })}
      </g>

      {/* DIYAS along the front steps */}
      <g fill="#fff3d0">
        {range(22).map((i) => (
          <g key={i} className={animate ? 'flame' : undefined} style={{ animationDelay: `${(i * 0.3) % 2}s` }}>
            <path d={`M${120 + i * 63} 545 q-4 6 0 12 q4 -6 0 -12 z`} />
          </g>
        ))}
      </g>
    </>
  );
}

function PalaceSvg({ animate = true }) {
  return (
    <svg
      viewBox="0 0 1600 580"
      preserveAspectRatio="xMidYMax slice"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
      focusable="false"
    >
      <Silhouette animate={animate} />
    </svg>
  );
}

export default memo(PalaceSvg);
