import { useCallback, useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Music2 } from 'lucide-react';
import weddingConfig from '../config/weddingConfig';
import { useMusic } from '../context/MusicContext';
import { FloralCorner, GoldDivider } from './Ornaments';
import { LetterReveal } from './Reveal';
import Visualizer from './Visualizer';
import { formatDate } from '../utils/helpers';

const { couple, wedding } = weddingConfig;

/* Stages: idle -> envelope -> open -> reveal -> (done)                  */
export default function IntroScreen({ onReveal, onDone }) {
  const music = useMusic();
  const [stage, setStage] = useState('idle');
  const [flapBehind, setFlapBehind] = useState(false);
  const timers = useRef([]);
  const busy = useRef(false);

  const clearTimers = () => timers.current.forEach(clearTimeout);
  useEffect(() => clearTimers, []);

  const later = (fn, ms) => timers.current.push(setTimeout(fn, ms));

  const enter = useCallback(() => {
    if (busy.current) return;
    busy.current = true;
    // 1) start the music (allowed: this runs inside the guest's tap/click)
    if (!music.playing) music.start();
    // 2) envelope animation
    setStage('envelope');
    later(() => setStage('open'), 650);
    later(() => setFlapBehind(true), 1000);
    later(() => {
      setStage('reveal');
      onReveal?.();
    }, 2150);
    later(() => onDone?.(), 3000);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [music, onDone, onReveal]);

  /* swipe up / scroll down also opens the invitation */
  useEffect(() => {
    let startY = null;
    const onWheel = (e) => e.deltaY > 24 && enter();
    const onStart = (e) => {
      startY = e.touches[0].clientY;
    };
    const onMove = (e) => {
      if (startY !== null && startY - e.touches[0].clientY > 60) {
        startY = null;
        enter();
      }
    };
    const onKey = (e) => (e.key === 'ArrowDown' || e.key === 'PageDown') && enter();
    window.addEventListener('wheel', onWheel, { passive: true });
    window.addEventListener('touchstart', onStart, { passive: true });
    window.addEventListener('touchmove', onMove, { passive: true });
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('wheel', onWheel);
      window.removeEventListener('touchstart', onStart);
      window.removeEventListener('touchmove', onMove);
      window.removeEventListener('keydown', onKey);
    };
  }, [enter]);

  const idle = stage === 'idle';
  const showEnvelope = stage === 'envelope' || stage === 'open' || stage === 'reveal';
  const opened = stage === 'open' || stage === 'reveal';

  return (
    <motion.div
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center overflow-hidden"
      style={{ touchAction: 'none', paddingTop: 'var(--sat)', paddingBottom: 'var(--sab)' }}
      initial={{ opacity: 1 }}
      animate={{ opacity: stage === 'reveal' ? 0 : 1 }}
      transition={{ duration: 0.85, ease: 'easeInOut' }}
      role="dialog"
      aria-modal="true"
      aria-label="Wedding invitation opening screen"
      onClick={() => showEnvelope && enter()}
    >
      {/* dark veil so the golden text is always readable */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(70% 60% at 50% 45%, rgba(4,8,21,0.72), rgba(4,8,21,0.35) 70%, rgba(4,8,21,0.15))',
        }}
      />

      {/* floral corners */}
      {[
        'left-0 top-0',
        'right-0 top-0 -scale-x-100',
        'bottom-0 left-0 -scale-y-100',
        'bottom-0 right-0 -scale-100',
      ].map((pos, i) => (
        <motion.div
          key={pos}
          className={`pointer-events-none absolute ${pos} w-[44vw] max-w-[360px] min-w-[150px] ${i > 1 ? 'opacity-70' : ''}`}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.6, delay: 0.2 + i * 0.12, ease: 'easeOut' }}
          style={{ transformOrigin: i % 2 ? '100% 0' : '0 0' }}
        >
          <motion.div
            animate={{ rotate: [0, 1.4, 0, -1.2, 0] }}
            transition={{ duration: 11 + i, repeat: Infinity, ease: 'easeInOut' }}
          >
            <FloralCorner className="h-auto w-full" />
          </motion.div>
        </motion.div>
      ))}

      {/* ---------- title block ---------- */}
      <AnimatePresence>
        {idle && (
          <motion.div
            key="title"
            className="relative z-10 flex w-full flex-col items-center px-6 pb-20 text-center"
            exit={{ opacity: 0, scale: 0.94, filter: 'blur(6px)', transition: { duration: 0.5 } }}
          >
            <motion.p
              className="eyebrow mb-5 !text-[0.7rem] sm:!text-xs"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 1 }}
            >
              {couple.inviteLine}
            </motion.p>

            <h1 className="flex flex-col items-center" aria-label={`${couple.groom} and ${couple.bride}`}>
              <LetterReveal
                text={couple.groom.toUpperCase()}
                delay={0.8}
                className="gold-text font-display text-[clamp(2.9rem,15vw,6.8rem)] font-medium leading-none tracking-[0.12em]"
              />
              <motion.span
                aria-hidden="true"
                className="font-script my-1 text-[clamp(2.2rem,9vw,3.8rem)] text-rose-300"
                initial={{ opacity: 0, scale: 0.6 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 1.7, duration: 1 }}
              >
                and
              </motion.span>
              <LetterReveal
                text={couple.bride.toUpperCase()}
                delay={1.9}
                className="gold-text font-display text-[clamp(2.9rem,15vw,6.8rem)] font-medium leading-none tracking-[0.12em]"
              />
            </h1>

            <motion.div
              className="mt-7 w-full"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 2.6, duration: 1 }}
            >
              <GoldDivider />
              <p className="mt-5 font-serif text-[clamp(1.05rem,4.4vw,1.5rem)] uppercase tracking-[0.42em] text-ivory">
                {couple.tagline}
              </p>
              <p className="mt-2 text-sm tracking-[0.2em] text-pearl/75">{formatDate(wedding.date)}</p>
            </motion.div>

            <motion.div
              className="mt-9 flex flex-col items-center gap-6"
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 3, duration: 0.9 }}
            >
              {/* glowing music icon (really toggles the music) */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  music.playing ? music.pause() : music.start();
                }}
                aria-label={music.playing ? 'Pause wedding music' : 'Play wedding music'}
                className="glass-strong music-glow flex h-14 w-14 items-center justify-center rounded-full text-gold-300"
              >
                {music.playing ? <Visualizer bars={4} width={22} height={20} /> : <Music2 size={22} strokeWidth={1.5} />}
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  enter();
                }}
                className="btn-gold !min-h-[58px] !px-8 text-[0.78rem] sm:!px-10"
                autoFocus
              >
                Enter Wedding Invitation
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ---------- envelope ---------- */}
      <AnimatePresence>
        {showEnvelope && (
          <motion.div
            key="env"
            className="absolute inset-0 z-20 flex items-center justify-center"
            style={{ perspective: 1100 }}
            initial={{ opacity: 0, scale: 0.8, y: 30 }}
            animate={{
              opacity: stage === 'reveal' ? 0 : 1,
              scale: stage === 'reveal' ? 1.7 : 1,
              y: 0,
            }}
            transition={{ duration: stage === 'reveal' ? 0.85 : 0.6, ease: [0.2, 0.8, 0.2, 1] }}
          >
            <div className="relative" style={{ width: 'min(78vw,340px)', aspectRatio: '1.5 / 1' }}>
              {/* back (inside of the envelope) */}
              <div
                className="absolute inset-0 rounded-md"
                style={{ background: 'linear-gradient(180deg,#14214a,#0b1430)', boxShadow: '0 30px 80px rgba(0,0,0,0.6), 0 0 60px rgba(220,191,126,0.18)', border: '1px solid rgba(220,191,126,0.5)' }}
              />

              {/* letter */}
              <motion.div
                className="absolute left-[6%] right-[6%] flex flex-col items-center justify-center rounded-sm text-center"
                style={{
                  top: '6%',
                  height: '88%',
                  zIndex: 2,
                  background: 'linear-gradient(180deg,#fbf6ea,#efe5cc)',
                  border: '1px solid #c9a45c',
                  boxShadow: '0 4px 20px rgba(0,0,0,0.35)',
                  color: '#0b1430',
                }}
                initial={{ y: 0 }}
                animate={{ y: opened ? '-62%' : 0, scale: opened ? 1.04 : 1 }}
                transition={{ delay: opened ? 0.55 : 0, duration: 1, ease: [0.2, 0.8, 0.2, 1] }}
              >
                <div className="pointer-events-none absolute inset-[6px] border border-[#c9a45c]/60" />
                <p className="text-[0.55rem] uppercase tracking-[0.35em] text-[#8a6a2c]">The wedding of</p>
                <p className="font-script mt-1 text-[clamp(1.5rem,7vw,2.2rem)] leading-none text-[#0b1430]">
                  {couple.groom} &amp; {couple.bride}
                </p>
                <span className="my-2 block h-px w-14 bg-[#c9a45c]" />
                <p className="text-[0.62rem] uppercase tracking-[0.25em] text-[#0b1430]/80">{formatDate(wedding.date)}</p>
              </motion.div>

              {/* front pocket */}
              <div className="pointer-events-none absolute inset-0" style={{ zIndex: 3 }}>
                <div
                  className="absolute inset-0 rounded-md"
                  style={{
                    clipPath: 'polygon(0 0, 50% 54%, 100% 0, 100% 100%, 0 100%)',
                    background: 'linear-gradient(160deg,#efe5cc,#d9ceb4)',
                  }}
                />
                <div
                  className="absolute inset-0"
                  style={{
                    clipPath: 'polygon(0 100%, 50% 46%, 100% 100%)',
                    background: 'linear-gradient(180deg,#e7dcc2,#cfc3a6)',
                    filter: 'drop-shadow(0 -2px 4px rgba(0,0,0,0.25))',
                  }}
                />
              </div>

              {/* flap */}
              <motion.div
                className="absolute left-0 right-0 top-0"
                style={{
                  height: '58%',
                  zIndex: flapBehind ? 1 : 4,
                  transformOrigin: 'top center',
                  clipPath: 'polygon(0 0, 100% 0, 50% 100%)',
                  background: 'linear-gradient(180deg,#f6eed9,#e2d6b9)',
                }}
                initial={{ rotateX: 0 }}
                animate={{ rotateX: opened ? -178 : 0 }}
                transition={{ duration: 0.75, ease: [0.4, 0, 0.2, 1] }}
              >
                <span
                  className="absolute left-1/2 top-[68%] flex h-[26%] w-[16%] -translate-x-1/2 items-center justify-center rounded-full"
                  style={{ background: 'radial-gradient(circle at 35% 30%,#f3e3bd,#b8933f)', boxShadow: '0 2px 8px rgba(0,0,0,0.4)' }}
                >
                  <span className="block h-1/2 w-1/2 rounded-full border border-[#8a6a2c]/60" />
                </span>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ---------- scroll indicator ---------- */}
      <AnimatePresence>
        {idle && (
          <motion.button
            type="button"
            key="scroll"
            onClick={(e) => {
              e.stopPropagation();
              enter();
            }}
            className="absolute bottom-[max(18px,var(--sab))] z-10 flex min-h-12 flex-col items-center gap-2 px-6 text-pearl/75"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ delay: 3.4, duration: 1 }}
            aria-label="Scroll down to open the invitation"
          >
            <span className="text-[0.66rem] uppercase tracking-[0.4em]">Scroll Down</span>
            <span className="relative flex h-8 w-5 justify-center rounded-full border border-gold-400/70 pt-1.5">
              <span className="scroll-dot block h-1.5 w-1 rounded-full bg-gold-300" />
            </span>
          </motion.button>
        )}
      </AnimatePresence>

      {/* tiny hint while the envelope animates */}
      {showEnvelope && stage !== 'reveal' && (
        <p className="sr-only" aria-live="polite">
          Opening the invitation
        </p>
      )}
    </motion.div>
  );
}
