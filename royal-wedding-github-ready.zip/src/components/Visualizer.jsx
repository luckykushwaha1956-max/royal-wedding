import { useEffect, useRef } from 'react';
import { useMusic } from '../context/MusicContext';

/* Real audio visualizer (reads the live audio spectrum).
   If the browser cannot provide spectrum data it falls back to
   animated CSS bars — only while music is really playing.            */
export default function Visualizer({ bars = 20, height = 36, width = 120, className = '' }) {
  const { playing, hasAnalyser, analyserRef } = useMusic();
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !hasAnalyser) return undefined;
    const ctx = canvas.getContext('2d');
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);
    const analyser = analyserRef.current;
    const data = new Uint8Array(analyser ? analyser.frequencyBinCount : 64);
    let raf = 0;
    const gap = 3;
    const bw = (width - gap * (bars - 1)) / bars;

    const draw = () => {
      ctx.clearRect(0, 0, width, height);
      if (analyser && playing) analyser.getByteFrequencyData(data);
      const grad = ctx.createLinearGradient(0, height, 0, 0);
      grad.addColorStop(0, '#b8933f');
      grad.addColorStop(1, '#f3e3bd');
      ctx.fillStyle = grad;
      for (let i = 0; i < bars; i++) {
        const idx = Math.floor((i / bars) * data.length * 0.7);
        const v = playing ? data[idx] / 255 : 0;
        const h = Math.max(3, v * height);
        const x = i * (bw + gap);
        const r = Math.min(bw / 2, 2);
        ctx.beginPath();
        ctx.roundRect ? ctx.roundRect(x, height - h, bw, h, r) : ctx.rect(x, height - h, bw, h);
        ctx.fill();
      }
      if (playing) raf = requestAnimationFrame(draw);
    };
    draw();
    return () => cancelAnimationFrame(raf);
  }, [playing, hasAnalyser, analyserRef, bars, height, width]);

  if (hasAnalyser) {
    return (
      <canvas
        ref={canvasRef}
        className={className}
        style={{ width, height }}
        aria-hidden="true"
      />
    );
  }

  return (
    <div
      className={`flex items-end gap-[3px] ${playing ? 'viz-playing' : ''} ${className}`}
      style={{ width, height }}
      aria-hidden="true"
    >
      {Array.from({ length: bars }, (_, i) => (
        <span
          key={i}
          className="viz-bar"
          style={{ flex: 1, '--d': `${0.6 + ((i * 37) % 7) * 0.12}s`, '--dl': `${(i % 5) * 0.09}s` }}
        />
      ))}
    </div>
  );
}
