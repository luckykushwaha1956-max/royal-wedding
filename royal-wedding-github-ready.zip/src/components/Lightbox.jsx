import { useCallback, useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';
import { asset } from '../utils/helpers';

/* Full-screen photo viewer: arrows, keyboard, swipe on phones, focus trap. */
export default function Lightbox({ images, index, onClose, onChange }) {
  const [dir, setDir] = useState(0);
  const closeRef = useRef(null);
  const prevRef = useRef(null);
  const nextRef = useRef(null);
  const opener = useRef(null);
  const count = images.length;

  const go = useCallback(
    (delta) => {
      setDir(delta);
      onChange((index + delta + count) % count);
    },
    [count, index, onChange],
  );

  /* remember what to focus after closing, and lock page scroll */
  useEffect(() => {
    opener.current = document.activeElement;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    closeRef.current?.focus();
    return () => {
      document.body.style.overflow = prevOverflow;
      opener.current?.focus?.();
    };
  }, []);

  /* keyboard */
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'Escape') onClose();
      else if (e.key === 'ArrowRight') go(1);
      else if (e.key === 'ArrowLeft') go(-1);
      else if (e.key === 'Tab') {
        const els = [closeRef.current, prevRef.current, nextRef.current].filter(Boolean);
        const i = els.indexOf(document.activeElement);
        e.preventDefault();
        const n = (i + (e.shiftKey ? -1 : 1) + els.length) % els.length;
        els[n].focus();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [go, onClose]);

  /* preload the neighbours */
  useEffect(() => {
    [index + 1, index - 1].forEach((i) => {
      const img = new Image();
      img.src = asset(images[(i + count) % count].src);
    });
  }, [index, images, count]);

  const cur = images[index];

  return (
    <motion.div
      role="dialog"
      aria-modal="true"
      aria-label="Photo viewer"
      className="fixed inset-0 z-[90] flex items-center justify-center"
      style={{ touchAction: 'none', background: 'rgba(3,6,16,0.94)', WebkitBackdropFilter: 'blur(10px)', backdropFilter: 'blur(10px)' }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
      onClick={onClose}
    >
      <div
        className="absolute inset-x-0 top-0 flex items-center justify-between px-4"
        style={{ paddingTop: 'calc(var(--sat) + 12px)' }}
        onClick={(e) => e.stopPropagation()}
      >
        <p className="text-sm tracking-[0.25em] text-pearl/80" aria-live="polite">
          {index + 1} / {count}
        </p>
        <button
          ref={closeRef}
          type="button"
          onClick={onClose}
          aria-label="Close photo viewer"
          className="glass-strong flex h-12 w-12 items-center justify-center rounded-full text-ivory"
        >
          <X size={22} />
        </button>
      </div>

      <div
        className="relative flex h-full w-full items-center justify-center overflow-hidden px-3 sm:px-20"
        onClick={(e) => e.stopPropagation()}
      >
        <AnimatePresence initial={false} custom={dir} mode="popLayout">
          <motion.figure
            key={index}
            custom={dir}
            variants={{
              enter: (d) => ({ x: d > 0 ? 120 : -120, opacity: 0, scale: 0.96 }),
              center: { x: 0, opacity: 1, scale: 1 },
              exit: (d) => ({ x: d > 0 ? -120 : 120, opacity: 0, scale: 0.96 }),
            }}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ duration: 0.45, ease: [0.2, 0.8, 0.2, 1] }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={0.35}
            onDragEnd={(_, info) => {
              if (info.offset.x < -70 || info.velocity.x < -500) go(1);
              else if (info.offset.x > 70 || info.velocity.x > 500) go(-1);
            }}
            className="m-0 flex max-h-[78svh] max-w-full cursor-grab flex-col items-center active:cursor-grabbing"
          >
            <img
              src={asset(cur.src)}
              alt={cur.alt}
              draggable="false"
              className="max-h-[72svh] w-auto max-w-full select-none rounded-2xl border border-gold-400/30 object-contain shadow-[0_30px_100px_rgba(0,0,0,0.7)]"
            />
            <figcaption className="mt-4 text-center font-serif text-lg text-pearl/90">{cur.alt}</figcaption>
          </motion.figure>
        </AnimatePresence>

        <button
          ref={prevRef}
          type="button"
          onClick={() => go(-1)}
          aria-label="Previous photo"
          className="glass-strong absolute left-2 top-1/2 flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full text-ivory sm:left-6"
        >
          <ChevronLeft size={24} />
        </button>
        <button
          ref={nextRef}
          type="button"
          onClick={() => go(1)}
          aria-label="Next photo"
          className="glass-strong absolute right-2 top-1/2 flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full text-ivory sm:right-6"
        >
          <ChevronRight size={24} />
        </button>
      </div>
    </motion.div>
  );
}
