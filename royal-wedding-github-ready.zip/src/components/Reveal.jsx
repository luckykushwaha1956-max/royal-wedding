import { motion, useReducedMotion } from 'framer-motion';

const EASE = [0.2, 0.8, 0.2, 1];

/** Fade + rise when scrolled into view. */
export function Reveal({
  children,
  delay = 0,
  y = 28,
  x = 0,
  scale = 1,
  duration = 0.9,
  className = '',
  as = 'div',
  once = true,
  ...rest
}) {
  const reduce = useReducedMotion();
  const Comp = motion[as] || motion.div;
  if (reduce) return <Comp className={className} {...rest}>{children}</Comp>;
  return (
    <Comp
      className={className}
      initial={{ opacity: 0, y, x, scale }}
      whileInView={{ opacity: 1, y: 0, x: 0, scale: 1 }}
      viewport={{ once, margin: '0px 0px -12% 0px' }}
      transition={{ duration, delay, ease: EASE }}
      {...rest}
    >
      {children}
    </Comp>
  );
}

/** Word-by-word text reveal for headings. */
export function TextReveal({ text, className = '', delay = 0, as = 'h2', stagger = 0.07, ...rest }) {
  const reduce = useReducedMotion();
  const Tag = motion[as] || motion.h2;
  const words = String(text).split(' ');
  if (reduce) return <Tag className={className} {...rest}>{text}</Tag>;
  return (
    <Tag
      className={className}
      aria-label={text}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: '0px 0px -10% 0px' }}
      transition={{ staggerChildren: stagger, delayChildren: delay }}
      {...rest}
    >
      {words.map((w, i) => (
        <span key={i} aria-hidden="true" className="inline-block overflow-hidden pb-[0.12em] align-bottom">
          <motion.span
            className="inline-block"
            variants={{
              hidden: { y: '110%', rotate: 3, opacity: 0 },
              show: { y: '0%', rotate: 0, opacity: 1, transition: { duration: 0.9, ease: EASE } },
            }}
          >
            {w}
            {i < words.length - 1 ? ' ' : ''}
          </motion.span>
        </span>
      ))}
    </Tag>
  );
}

/** Letter-by-letter blur-in (used for GROOM / BRIDE). */
export function LetterReveal({ text, className = '', delay = 0, stagger = 0.06, animateNow = true }) {
  const reduce = useReducedMotion();
  if (reduce) return <span className={className}>{text}</span>;
  return (
    <motion.span
      className={className}
      aria-label={text}
      initial="hidden"
      animate={animateNow ? 'show' : 'hidden'}
      transition={{ staggerChildren: stagger, delayChildren: delay }}
    >
      {text.split('').map((c, i) => (
        <motion.span
          key={i}
          aria-hidden="true"
          className="inline-block"
          variants={{
            hidden: { opacity: 0, y: 18, filter: 'blur(10px)' },
            show: { opacity: 1, y: 0, filter: 'blur(0px)', transition: { duration: 1, ease: EASE } },
          }}
        >
          {c === ' ' ? ' ' : c}
        </motion.span>
      ))}
    </motion.span>
  );
}
