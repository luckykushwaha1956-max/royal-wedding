import { useId } from 'react';

/* Hand-built decorative SVGs: flowers, floral corners, dividers, mandala. */

export function Flower({ cx, cy, r = 24, petals = 8, a = '#fbeee4', b = '#d99aa4', center = '#dcbf7e', id }) {
  const gid = `fl-${id}`;
  return (
    <g transform={`translate(${cx} ${cy})`}>
      <defs>
        <radialGradient id={gid} cx="50%" cy="80%" r="80%">
          <stop offset="0%" stopColor={b} />
          <stop offset="100%" stopColor={a} />
        </radialGradient>
      </defs>
      {Array.from({ length: petals }, (_, i) => (
        <ellipse
          key={i}
          cx="0"
          cy={-r * 0.52}
          rx={r * 0.3}
          ry={r * 0.56}
          fill={`url(#${gid})`}
          stroke="rgba(220,191,126,0.55)"
          strokeWidth="0.8"
          transform={`rotate(${(360 / petals) * i})`}
          opacity="0.95"
        />
      ))}
      {Array.from({ length: petals }, (_, i) => (
        <ellipse
          key={`i${i}`}
          cx="0"
          cy={-r * 0.3}
          rx={r * 0.15}
          ry={r * 0.3}
          fill={a}
          opacity="0.75"
          transform={`rotate(${(360 / petals) * i + 360 / petals / 2})`}
        />
      ))}
      <circle r={r * 0.17} fill={center} />
      <circle r={r * 0.08} fill="#fff3d0" />
    </g>
  );
}

function Leaf({ x, y, rot = 0, s = 1 }) {
  return (
    <path
      d="M0 0 C 8 -10 22 -12 34 -4 C 22 4 8 8 0 0 Z"
      transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}
      fill="rgba(220,191,126,0.18)"
      stroke="rgba(220,191,126,0.75)"
      strokeWidth="1"
    />
  );
}

/** Floral cluster for a corner. Mirror it with CSS transforms. */
export function FloralCorner({ className = '', style }) {
  const uid = useId().replace(/:/g, '');
  return (
    <svg viewBox="0 0 320 320" className={className} style={style} aria-hidden="true" focusable="false">
      <path
        d="M4 316 C 40 230 70 150 150 96 C 200 62 262 52 316 4"
        fill="none"
        stroke="rgba(220,191,126,0.85)"
        strokeWidth="1.6"
      />
      <path
        d="M4 250 C 36 200 60 150 112 118"
        fill="none"
        stroke="rgba(220,191,126,0.5)"
        strokeWidth="1.1"
      />
      <Leaf x={52} y={232} rot={-60} s={1.2} />
      <Leaf x={80} y={190} rot={-40} s={1.1} />
      <Leaf x={112} y={150} rot={-30} s={1.2} />
      <Leaf x={150} y={110} rot={-12} s={1.1} />
      <Leaf x={196} y={80} rot={-8} s={1.1} />
      <Leaf x={242} y={62} rot={-20} s={1} />
      <Leaf x={36} y={286} rot={-85} s={1} />
      <Leaf x={74} y={168} rot={-170} s={0.9} />
      <Leaf x={134} y={118} rot={-150} s={0.9} />
      <Leaf x={188} y={92} rot={-165} s={0.8} />
      <Flower cx={46} cy={262} r={30} id={`${uid}a`} />
      <Flower cx={118} cy={168} r={38} petals={10} id={`${uid}b`} a="#f7f1e3" b="#e8b9bf" />
      <Flower cx={196} cy={102} r={28} id={`${uid}c`} />
      <Flower cx={262} cy={60} r={20} petals={7} id={`${uid}d`} a="#f7f1e3" b="#d9d4ca" />
      <Flower cx={22} cy={196} r={16} petals={6} id={`${uid}e`} a="#f7f1e3" b="#d9d4ca" />
      <Flower cx={92} cy={104} r={14} petals={6} id={`${uid}f`} />
      {[
        [72, 76],
        [30, 150],
        [160, 38],
        [210, 150],
        [128, 230],
      ].map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r="2.2" fill="#f3e3bd" opacity="0.85" />
      ))}
    </svg>
  );
}

/** Thin gold line with a diamond in the middle. */
export function GoldDivider({ className = '' }) {
  return (
    <div className={`flex items-center justify-center gap-3 ${className}`} aria-hidden="true">
      <span className="divider-gold block w-16 sm:w-28" />
      <svg width="16" height="16" viewBox="0 0 16 16">
        <path d="M8 1 L15 8 L8 15 L1 8 Z" fill="none" stroke="#dcbf7e" strokeWidth="1.2" />
        <circle cx="8" cy="8" r="1.8" fill="#f3e3bd" />
      </svg>
      <span className="divider-gold block w-16 sm:w-28" />
    </div>
  );
}

/** Soft mandala (used faintly behind headings & event cards). */
export function Mandala({ className = '', stroke = 'rgba(220,191,126,0.5)' }) {
  const rings = [
    { r: 150, n: 24, len: 18 },
    { r: 118, n: 16, len: 24 },
    { r: 80, n: 12, len: 22 },
    { r: 44, n: 8, len: 16 },
  ];
  return (
    <svg viewBox="-200 -200 400 400" className={className} aria-hidden="true" focusable="false">
      <g fill="none" stroke={stroke} strokeWidth="1">
        {[182, 160, 100, 60, 24].map((r) => (
          <circle key={r} r={r} />
        ))}
        {rings.map(({ r, n, len }) =>
          Array.from({ length: n }, (_, i) => (
            <path
              key={`${r}-${i}`}
              d={`M0 ${-r} q ${len * 0.5} ${len * 0.5} 0 ${len} q ${-len * 0.5} ${-len * 0.5} 0 ${-len}`}
              transform={`rotate(${(360 / n) * i})`}
            />
          )),
        )}
        {Array.from({ length: 12 }, (_, i) => (
          <line key={i} x1="0" y1="-24" x2="0" y2="-182" transform={`rotate(${i * 30})`} opacity="0.4" />
        ))}
      </g>
    </svg>
  );
}

/** Wax-seal style heart / double ring mark. */
export function RingsMark({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 40" aria-hidden="true" focusable="false">
      <circle cx="24" cy="20" r="14" fill="none" stroke="#dcbf7e" strokeWidth="2" />
      <circle cx="40" cy="20" r="14" fill="none" stroke="#f3e3bd" strokeWidth="2" />
      <circle cx="32" cy="7" r="2.5" fill="#fff3d0" />
    </svg>
  );
}
