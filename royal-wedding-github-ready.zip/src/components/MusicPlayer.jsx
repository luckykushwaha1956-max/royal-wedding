import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  AlertCircle,
  Music2,
  Pause,
  Play,
  SkipBack,
  SkipForward,
  Volume1,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { useMusic } from '../context/MusicContext';
import Visualizer from './Visualizer';

/* Always-visible music control (top-right). Tap to open the full player. */
export default function MusicPlayer() {
  const m = useMusic();
  const [open, setOpen] = useState(false);
  const wrapRef = useRef(null);

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === 'Escape' && setOpen(false);
    const onDown = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false);
    };
    window.addEventListener('keydown', onKey);
    window.addEventListener('pointerdown', onDown);
    return () => {
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('pointerdown', onDown);
    };
  }, [open]);

  const VolIcon = m.muted || m.volume === 0 ? VolumeX : m.volume < 0.45 ? Volume1 : Volume2;
  const shownVolume = m.muted ? 0 : m.volume;

  return (
    <div
      ref={wrapRef}
      className="fixed z-[60]"
      style={{
        top: 'calc(var(--sat) + 12px)',
        right: 'max(12px, var(--sar))',
      }}
    >
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-label={open ? 'Close music player' : 'Open music player'}
        aria-expanded={open}
        aria-controls="music-panel"
        className={`glass-strong relative flex h-12 min-w-12 items-center justify-center gap-2 rounded-full px-3 text-gold-300 transition-transform active:scale-95 ${
          m.playing ? 'music-glow' : ''
        }`}
      >
        {m.playing ? (
          <Visualizer bars={4} width={22} height={18} />
        ) : (
          <Music2 size={20} strokeWidth={1.6} />
        )}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            id="music-panel"
            role="dialog"
            aria-label="Wedding music player"
            initial={{ opacity: 0, y: -8, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.96 }}
            transition={{ duration: 0.25, ease: [0.2, 0.8, 0.2, 1] }}
            className="glass-strong absolute right-0 top-14 w-[min(92vw,360px)] origin-top-right rounded-3xl p-5"
          >
            <div className="mb-4 flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="eyebrow !text-[0.66rem]">Now playing</p>
                <p className="mt-1 truncate font-serif text-[1.35rem] leading-tight text-ivory">
                  {m.track?.title}
                </p>
                <p className="text-xs text-pearl/70">{m.track?.mood}</p>
              </div>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Close music player"
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-pearl/80 hover:bg-white/10"
              >
                <X size={18} />
              </button>
            </div>

            <div className="mb-4 flex justify-center">
              <Visualizer bars={24} width={260} height={44} />
            </div>

            {m.trackMissing && (
              <p
                role="alert"
                className="mb-4 flex items-start gap-2 rounded-xl border border-rose-400/40 bg-rose-400/10 p-3 text-xs text-rose-300"
              >
                <AlertCircle size={16} className="mt-0.5 shrink-0" />
                <span>
                  This music file was not found. Add an MP3 named{' '}
                  <code className="text-ivory">{m.track?.src.split('/').pop()}</code> to{' '}
                  <code className="text-ivory">public/assets/music/</code>.
                </span>
              </p>
            )}

            <div className="mb-4 flex items-center justify-center gap-5">
              <button
                type="button"
                onClick={m.prev}
                aria-label="Previous track"
                className="flex h-12 w-12 items-center justify-center rounded-full text-gold-300 hover:bg-white/10"
              >
                <SkipBack size={22} />
              </button>
              <button
                type="button"
                onClick={m.toggle}
                aria-label={m.playing ? 'Pause music' : 'Play music'}
                className="btn-gold !h-16 !min-h-16 !w-16 !p-0"
              >
                {m.playing ? <Pause size={26} fill="currentColor" /> : <Play size={26} fill="currentColor" className="ml-1" />}
              </button>
              <button
                type="button"
                onClick={m.next}
                aria-label="Next track"
                className="flex h-12 w-12 items-center justify-center rounded-full text-gold-300 hover:bg-white/10"
              >
                <SkipForward size={22} />
              </button>
            </div>

            <div className="mb-4 flex items-center gap-2">
              <button
                type="button"
                onClick={m.toggleMute}
                aria-label={m.muted ? 'Unmute' : 'Mute'}
                aria-pressed={m.muted}
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-gold-300 hover:bg-white/10"
              >
                <VolIcon size={20} />
              </button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={shownVolume}
                onChange={(e) => m.setVolume(parseFloat(e.target.value))}
                aria-label="Volume"
                className="gold-range"
                style={{ '--fill': `${shownVolume * 100}%` }}
              />
            </div>

            <ul className="space-y-1" aria-label="Choose a track">
              {m.tracks.map((t, i) => {
                const active = i === m.trackIndex;
                return (
                  <li key={t.id}>
                    <button
                      type="button"
                      onClick={() => m.selectTrack(i)}
                      aria-current={active ? 'true' : undefined}
                      className={`flex min-h-12 w-full items-center gap-3 rounded-xl px-3 py-2 text-left transition-colors ${
                        active ? 'bg-gold-400/15 text-gold-200' : 'text-pearl/85 hover:bg-white/5'
                      }`}
                    >
                      <span className="flex h-6 w-6 shrink-0 items-center justify-center text-xs text-gold-400">
                        {active && m.playing ? <Visualizer bars={3} width={14} height={14} /> : i + 1}
                      </span>
                      <span className="min-w-0 flex-1 truncate text-sm">{t.title}</span>
                      {m.missing[t.id] && <AlertCircle size={14} className="shrink-0 text-rose-300" aria-label="File missing" />}
                    </button>
                  </li>
                );
              })}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
