import { Reveal, TextReveal } from './Reveal';
import { GoldDivider } from './Ornaments';

export default function SectionHeading({ id, eyebrow, title, subtitle, align = 'center', className = '' }) {
  return (
    <header className={`${align === 'center' ? 'mx-auto text-center' : ''} max-w-3xl ${className}`}>
      {eyebrow && (
        <Reveal>
          <p className="eyebrow mb-5">{eyebrow}</p>
        </Reveal>
      )}
      <TextReveal
        as="h2"
        id={id}
        text={title}
        className="font-serif text-[clamp(2.3rem,7.5vw,4.4rem)] font-medium leading-[1.08] text-ivory"
      />
      <Reveal delay={0.25} className="mt-6">
        <GoldDivider />
      </Reveal>
      {subtitle && (
        <Reveal delay={0.35}>
          <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-pearl/85 sm:text-lg">
            {subtitle}
          </p>
        </Reveal>
      )}
    </header>
  );
}
