import { memo, useEffect, useMemo, useRef } from 'react';
import PalaceSvg from './PalaceSvg';
import ParticleField from '../animations/ParticleField';
import { clamp, isCoarsePointer, prefersReducedMotion } from '../utils/helpers';

/* Always-moving, multi-layer background:
   sky -> stars -> light rays -> clouds -> palace (+ reflection) ->
   lanterns -> bokeh -> canvas petals & golden dust -> vignette.
   Each layer has its own animation and its own parallax depth
   (pointer movement on desktop, scrolling everywhere).                  */

const seeded = (i, a, b) => {
  const x = Math.sin(i * 127.1 + 311.7) * 43758.5453;
  return a + (x - Math.floor(x)) * (b - a);
};

function CinematicBackground() {
  const rootRef = useRef(null);

  const stars = useMemo(
    () =>
      Array.from({ length: 46 }, (_, i) => ({
        left: seeded(i, 0, 100),
        top: seeded(i + 50, 0, 62),
        d: seeded(i + 99, 2.5, 6.5),
        dl: seeded(i + 7, 0, 5),
        s: seeded(i + 3, 1, 2.6),
      })),
    [],
  );
  const lanterns = useMemo(
    () =>
      Array.from({ length: 8 }, (_, i) => ({
        left: 6 + i * 12 + seeded(i, -3, 3),
        s: seeded(i + 4, 12, 22),
        dur: seeded(i + 8, 24, 40),
        dl: -seeded(i + 2, 0, 30),
        sway: seeded(i + 6, -40, 40),
      })),
    [],
  );
  const bokeh = useMemo(
    () =>
      Array.from({ length: 12 }, (_, i) => ({
        left: seeded(i + 11, 2, 96),
        top: seeded(i + 21, 8, 85),
        size: seeded(i + 31, 28, 96),
        b: seeded(i + 41, 2, 7),
        o: seeded(i + 51, 0.18, 0.42),
        dur: seeded(i + 61, 10, 20),
        dl: -seeded(i + 71, 0, 14),
        dx: seeded(i + 81, -30, 30),
        dy: seeded(i + 91, -50, -10),
      })),
    [],
  );

  /* parallax from pointer + scroll, written straight to CSS variables
     (no React re-renders, so it stays smooth) */
  useEffect(() => {
    const el = rootRef.current;
    if (!el || prefersReducedMotion()) return undefined;
    const fine = !isCoarsePointer();
    let tx = 0;
    let ty = 0;
    let cx = 0;
    let cy = 0;
    let sy = 0;
    let raf = 0;
    let pending = false;

    const apply = () => {
      pending = false;
      cx += (tx - cx) * 0.08;
      cy += (ty - cy) * 0.08;
      const y = clamp(window.scrollY, 0, 500);
      el.style.setProperty('--px', cx.toFixed(4));
      el.style.setProperty('--py', cy.toFixed(4));
      el.style.setProperty('--sy', y.toFixed(1));
      el.style.setProperty('--read', clamp(window.scrollY / (window.innerHeight * 0.9), 0, 1).toFixed(3));
      sy = y;
      if (Math.abs(tx - cx) > 0.002 || Math.abs(ty - cy) > 0.002) request();
    };
    const request = () => {
      if (!pending) {
        pending = true;
        raf = requestAnimationFrame(apply);
      }
    };
    const onMove = (e) => {
      tx = (e.clientX / window.innerWidth - 0.5) * 2;
      ty = (e.clientY / window.innerHeight - 0.5) * 2;
      request();
    };
    window.addEventListener('scroll', request, { passive: true });
    if (fine) window.addEventListener('pointermove', onMove, { passive: true });
    request();
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('scroll', request);
      window.removeEventListener('pointermove', onMove);
      void sy;
    };
  }, []);

  return (
    <div ref={rootRef} className="cine" aria-hidden="true">
      <div className="cine-layer cine-sky" style={{ '--depth': 3, '--sdepth': 0.01 }} />

      <div className="cine-layer cine-stars" style={{ '--depth': 6, '--sdepth': 0.02 }}>
        {stars.map((s, i) => (
          <span
            key={i}
            style={{
              left: `${s.left}%`,
              top: `${s.top}%`,
              width: s.s,
              height: s.s,
              '--d': `${s.d}s`,
              '--dl': `${s.dl}s`,
            }}
          />
        ))}
      </div>

      <div className="cine-layer cine-rays" style={{ '--depth': 8, '--sdepth': 0.02 }}>
        <i />
        <i />
      </div>

      <div className="cine-layer" style={{ '--depth': 12, '--sdepth': 0.03 }}>
        <div className="cine-cloud" style={{ top: '8%', width: '70vw', height: '22vh', '--spd': '85s', '--dl': '-20s' }} />
        <div className="cine-cloud" style={{ top: '24%', width: '55vw', height: '16vh', '--spd': '65s', '--dl': '-45s', opacity: 0.8 }} />
        <div className="cine-cloud" style={{ top: '40%', width: '80vw', height: '20vh', '--spd': '110s', '--dl': '-70s', opacity: 0.6 }} />
      </div>

      <div className="cine-layer cine-palace" style={{ '--depth': 16, '--sdepth': 0.04 }}>
        <PalaceSvg />
        <div className="pal-reflect">
          <PalaceSvg animate={false} />
        </div>
      </div>

      <div className="cine-layer" style={{ '--depth': 22, '--sdepth': 0.05 }}>
        {lanterns.map((l, i) => (
          <i
            key={i}
            className="cine-lantern"
            style={{
              left: `${l.left}%`,
              '--s': `${l.s}px`,
              '--dur': `${l.dur}s`,
              '--dl': `${l.dl}s`,
              '--sway': `${l.sway}px`,
              display: undefined,
            }}
            data-mobile-hide={i > 4 ? 'true' : undefined}
          />
        ))}
      </div>

      <div className="cine-layer cine-bokeh" style={{ '--depth': 28, '--sdepth': 0.06 }}>
        {bokeh.map((b, i) => (
          <span
            key={i}
            data-mobile-hide={i > 6 ? 'true' : undefined}
            style={{
              left: `${b.left}%`,
              top: `${b.top}%`,
              width: b.size,
              height: b.size,
              '--b': `${b.b}px`,
              '--o': b.o,
              '--dur': `${b.dur}s`,
              '--dl': `${b.dl}s`,
              '--dx': `${b.dx}px`,
              '--dy': `${b.dy}px`,
            }}
          />
        ))}
      </div>

      <ParticleField petals={26} dust={60} />

      <div className="cine-vignette" />
      <div className="cine-readable" />
    </div>
  );
}

export default memo(CinematicBackground);
