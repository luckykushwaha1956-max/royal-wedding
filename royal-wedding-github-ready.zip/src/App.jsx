import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import weddingConfig from './config/weddingConfig';
import { MusicProvider } from './context/MusicContext';
import CinematicBackground from './components/CinematicBackground';
import IntroScreen from './components/IntroScreen';
import MusicPlayer from './components/MusicPlayer';
import { BottomNav, TopNav } from './components/Navigation';
import Home from './sections/Home';
import Story from './sections/Story';
import Events from './sections/Events';
import Gallery from './sections/Gallery';
import Venue from './sections/Venue';
import Rsvp from './sections/Rsvp';
import Family from './sections/Family';
import Contact from './sections/Contact';

/* phase: 'intro'  -> only the opening screen
          'reveal' -> main site fades in under the fading intro
          'main'   -> intro removed                                        */
export default function App() {
  const [phase, setPhase] = useState('intro');

  useEffect(() => {
    document.title = weddingConfig.site.title;
  }, []);

  useEffect(() => {
    document.body.classList.toggle('is-locked', phase === 'intro');
    if (phase === 'reveal') window.scrollTo(0, 0);
    return () => document.body.classList.remove('is-locked');
  }, [phase]);

  const siteVisible = phase !== 'intro';

  return (
    <MusicProvider>
      <a href="#home" className="skip-link">
        Skip to invitation
      </a>

      <CinematicBackground />

      {siteVisible && (
        <>
          <motion.main
            id="main"
            className="with-nav relative z-10"
            initial={{ opacity: 0, scale: 1.04, filter: 'blur(10px)' }}
            animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
            transition={{ duration: 1.3, ease: [0.2, 0.8, 0.2, 1] }}
          >
            <Home />
            <Story />
            <Events />
            <Gallery />
            <Venue />
            <Rsvp />
            <Family />
            <Contact />
          </motion.main>
          <TopNav />
          <BottomNav />
          <MusicPlayer />
        </>
      )}

      {phase !== 'main' && (
        <IntroScreen onReveal={() => setPhase('reveal')} onDone={() => setPhase('main')} />
      )}
    </MusicProvider>
  );
}
