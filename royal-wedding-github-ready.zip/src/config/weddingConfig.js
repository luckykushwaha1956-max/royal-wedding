/* =====================================================================
   THE ROYAL WEDDING EXPERIENCE — CENTRAL CONFIGURATION
   =====================================================================
   Almost everything you may want to change lives in THIS ONE FILE:
   names, dates, times, venues, family details, music, photos, contacts.

   Tips
   - Only change the text between the quotes "like this".
   - Photos: put your file in public/assets/images/... and keep the same
     file name (or change the path here).
   - Dates are written as "YYYY-MM-DD"  (example: "2026-11-26").
   - Times are written in 24-hour style "HH:MM" (example: "20:00" = 8 PM).
   ===================================================================== */

/* ---------- 1. THE BIG DATE (change this one and the countdown, home
        page and events update automatically) ---------- */
const WEDDING_DATE = '2026-11-26'; // main wedding day (temporary date)
const WEDDING_TIME = '20:00'; // time the countdown counts down to
const TIMEZONE_OFFSET = '+05:30'; // India Standard Time

/* Helper: "fromWedding(-2)" means "2 days before the wedding date".
   You can replace it with a fixed date like '2026-11-24' at any time. */
const fromWedding = (days) => {
  const d = new Date(`${WEDDING_DATE}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
};

export const weddingConfig = {
  /* ---------- 2. WEBSITE INFO ---------- */
  site: {
    title: 'Groom & Bride — Wedding Invitation',
    shareTitle: 'You are invited to our wedding',
    shareText:
      'We would be honoured to have you celebrate our wedding with us. Open your invitation.',
    // Paste your final website link here once it is online (used by Share).
    // Leave empty to share the current page address.
    shareUrl: '',
  },

  /* ---------- 3. THE COUPLE ---------- */
  couple: {
    groom: 'Groom',
    bride: 'Bride',
    tagline: 'Together Forever',
    inviteLine: 'Together with their families',
    invitationMessage:
      'With joyful hearts and the blessings of our elders, we invite you to celebrate the beginning of our forever.',
  },

  /* ---------- 4. MAIN WEDDING DATE & TIME ---------- */
  wedding: {
    date: WEDDING_DATE,
    time: WEDDING_TIME,
    timezoneOffset: TIMEZONE_OFFSET,
  },

  /* ---------- 5. MAIN VENUE ----------
     mapQuery  : what Google Maps should search for. Write the venue name
                 and city, e.g. "Hotel Taj Palace, New Delhi".
                 While it is empty the map shows a friendly notice.
     mapLink   : (optional) paste a Google Maps "Share" link for an exact
                 pin. If given, GET DIRECTIONS opens this link.            */
  venue: {
    name: 'Venue Name',
    address: 'Complete Venue Address',
    city: 'City',
    mapQuery: '',
    mapLink: '',
    photos: [
      { src: 'assets/images/venue/venue-1.jpg', alt: 'Venue — grand entrance' },
      { src: 'assets/images/venue/venue-2.jpg', alt: 'Venue — wedding lawn' },
      { src: 'assets/images/venue/venue-3.jpg', alt: 'Venue — banquet hall' },
    ],
  },

  /* ---------- 6. OUR STORY (placeholder text — edit freely) ---------- */
  story: {
    eyebrow: 'Our Story',
    heading: 'Two hearts, one beautiful journey',
    intro:
      'Some stories begin quietly and grow into something extraordinary. This is ours, and we are so happy to share the next chapter with the people we love.',
    // Add / remove milestones. "image" is optional.
    milestones: [
      {
        title: 'The Beginning',
        text: 'Every great love story has a first chapter. Write yours here.',
        image: 'assets/images/story/story-1.jpg',
      },
      {
        title: 'Growing Together',
        text: 'Moments, memories and little things that became everything.',
        image: 'assets/images/story/story-2.jpg',
      },
      {
        title: 'The Promise',
        text: 'A promise to walk together, today and always.',
        image: 'assets/images/story/story-3.jpg',
      },
    ],
  },

  /* ---------- 7. WEDDING EVENTS ----------
     Each event can be edited on its own.
     date            : fromWedding(-2) = two days before, or '2026-11-24'
     time            : any text you like, e.g. '11:00 AM onwards'
     image           : photo shown on the card (replace the file)
     showLocation    : true = show the "View Location" button
     mapQuery / mapLink : where that button goes. If empty, the main
                          venue above is used.
     theme           : visual identity (petals, henna, sparkle, lamps,
                          glow, bokeh) — you can leave it as it is.       */
  events: [
    {
      id: 'haldi',
      name: 'Haldi Ceremony',
      tagline: 'A golden morning of blessings',
      date: fromWedding(-2),
      time: '11:00 AM onwards',
      venue: 'Venue Name, City',
      locationLabel: 'Venue',
      description:
        'A joyful morning of turmeric, flowers and laughter. Dress in soft pastels and come ready to celebrate.',
      image: 'assets/images/events/haldi.jpg',
      showLocation: true,
      mapQuery: '',
      mapLink: '',
      theme: 'petals',
    },
    {
      id: 'mehendi',
      name: 'Mehendi Ceremony',
      tagline: 'Intricate patterns, endless joy',
      date: fromWedding(-2),
      time: '4:00 PM onwards',
      venue: 'Venue Name, City',
      locationLabel: 'Venue',
      description:
        'An afternoon of henna artistry, music and sweet conversations, set among fragrant flowers.',
      image: 'assets/images/events/mehendi.jpg',
      showLocation: true,
      mapQuery: '',
      mapLink: '',
      theme: 'henna',
    },
    {
      id: 'sangeet',
      name: 'Sangeet Night',
      tagline: 'An evening of music and dance',
      date: fromWedding(-1),
      time: '7:30 PM onwards',
      venue: 'Venue Name, City',
      locationLabel: 'Venue',
      description:
        'Music, dance performances and dinner under the lights. Bring your best moves and your brightest smile.',
      image: 'assets/images/events/sangeet.jpg',
      showLocation: true,
      mapQuery: '',
      mapLink: '',
      theme: 'sparkle',
    },
    {
      id: 'baraat',
      name: 'Baraat',
      tagline: 'The grand procession',
      date: fromWedding(0),
      time: '6:00 PM',
      venue: 'Starting Location',
      locationLabel: 'Starting Location',
      description:
        'The groom arrives in royal procession with music, dhol and dance. Join us as we welcome the celebration.',
      image: 'assets/images/events/baraat.jpg',
      showLocation: false,
      mapQuery: '',
      mapLink: '',
      theme: 'lamps',
    },
    {
      id: 'phere',
      name: 'Wedding Ceremony / Phere',
      tagline: 'Seven vows, one lifetime',
      date: fromWedding(0),
      time: '8:00 PM',
      venue: 'Venue Name, City',
      locationLabel: 'Venue',
      description:
        'The sacred ceremony beneath the royal mandap, where two families become one.',
      image: 'assets/images/events/phere.jpg',
      showLocation: false,
      mapQuery: '',
      mapLink: '',
      theme: 'glow',
    },
    {
      id: 'reception',
      name: 'Reception',
      tagline: 'A night to remember',
      date: fromWedding(1),
      time: '7:00 PM onwards',
      venue: 'Venue Name, City',
      locationLabel: 'Venue',
      description:
        'An elegant evening of dinner, music and warm wishes to celebrate the newly married couple.',
      image: 'assets/images/events/reception.jpg',
      showLocation: false,
      mapQuery: '',
      mapLink: '',
      theme: 'bokeh',
    },
  ],

  /* ---------- 8. COUNTDOWN TEXT ---------- */
  countdown: {
    title: 'Counting the moments',
    finishedMessage: 'THE CELEBRATION HAS BEGUN!',
  },

  /* ---------- 9. PHOTO GALLERY ----------
     category must be one of: couple, family, preparation, prewedding,
     celebration. Add as many photos as you like.                       */
  gallery: {
    heading: 'Moments we cherish',
    categories: [
      { id: 'all', label: 'All' },
      { id: 'couple', label: 'Couple' },
      { id: 'family', label: 'Family' },
      { id: 'preparation', label: 'Preparation' },
      { id: 'prewedding', label: 'Pre-Wedding' },
      { id: 'celebration', label: 'Celebration' },
    ],
    images: [
      { src: 'assets/images/gallery/couple-1.jpg', alt: 'Couple photograph 1', category: 'couple', ratio: 'portrait' },
      { src: 'assets/images/gallery/prewedding-1.jpg', alt: 'Pre-wedding memory 1', category: 'prewedding', ratio: 'landscape' },
      { src: 'assets/images/gallery/family-1.jpg', alt: 'Family photograph 1', category: 'family', ratio: 'portrait' },
      { src: 'assets/images/gallery/celebration-1.jpg', alt: 'Celebration photograph 1', category: 'celebration', ratio: 'landscape' },
      { src: 'assets/images/gallery/couple-2.jpg', alt: 'Couple photograph 2', category: 'couple', ratio: 'landscape' },
      { src: 'assets/images/gallery/preparation-1.jpg', alt: 'Wedding preparation 1', category: 'preparation', ratio: 'portrait' },
      { src: 'assets/images/gallery/family-2.jpg', alt: 'Family photograph 2', category: 'family', ratio: 'landscape' },
      { src: 'assets/images/gallery/prewedding-2.jpg', alt: 'Pre-wedding memory 2', category: 'prewedding', ratio: 'portrait' },
      { src: 'assets/images/gallery/celebration-2.jpg', alt: 'Celebration photograph 2', category: 'celebration', ratio: 'portrait' },
      { src: 'assets/images/gallery/preparation-2.jpg', alt: 'Wedding preparation 2', category: 'preparation', ratio: 'landscape' },
    ],
  },

  /* ---------- 10. RSVP ----------
     endpoint : your Google Apps Script "Web app" link (see README, step
                "RSVP setup"). While empty, the form will NOT pretend to
                save anything — it tells the guest honestly and offers
                WhatsApp instead (if a WhatsApp number is set below).
     whatsapp : country code + number, digits only, e.g. '919999999999'  */
  rsvp: {
    heading: 'Will you join us?',
    intro: 'Kindly let us know if you can make it, so we can welcome you properly.',
    deadlineText: 'Kindly respond at your earliest convenience.',
    endpoint: '',
    whatsapp: '',
    maxGuests: 10,
  },

  /* ---------- 11. FAMILY ---------- */
  family: {
    heading: 'With the blessings of our families',
    message:
      'It is with immense joy and gratitude that our families invite you to bless the couple with your presence and good wishes.',
    blessings:
      'May the love you share grow deeper with every passing year, and may your home always be filled with warmth, laughter and light.',
    groomSide: {
      title: "Groom's Family",
      parents: ["Groom's Father", "Groom's Mother"],
      note: 'Along with all family members',
    },
    brideSide: {
      title: "Bride's Family",
      parents: ["Bride's Father", "Bride's Mother"],
      note: 'Along with all family members',
    },
  },

  /* ---------- 12. CONTACT & CLOSING ----------
     Leave phone empty ('') to hide the Call button for that person. */
  contact: {
    thankYou: 'Thank You',
    closingMessage:
      'Your presence is the greatest gift. We look forward to celebrating this beautiful day with you.',
    people: [
      { name: 'Contact Person 1', relation: "Groom's side", phone: '', whatsapp: '' },
      { name: 'Contact Person 2', relation: "Bride's side", phone: '', whatsapp: '' },
    ],
    email: '',
  },

  /* ---------- 13. MUSIC ----------
     Put MP3 files in public/assets/music/ and list them here.
     The four files that come with this project are original
     PLACEHOLDER tracks — replace them with music you have the
     right to use.                                                      */
  music: {
    defaultVolume: 0.6,
    tracks: [
      { id: 'royal', title: 'Royal Indian Instrumental', mood: 'Sitar & tanpura', src: 'assets/music/royal-instrumental.mp3' },
      { id: 'piano', title: 'Romantic Piano', mood: 'Soft & timeless', src: 'assets/music/romantic-piano.mp3' },
      { id: 'shehnai', title: 'Traditional Shehnai', mood: 'Auspicious & warm', src: 'assets/music/shehnai.mp3' },
      { id: 'celebration', title: 'Wedding Celebration', mood: 'Festive rhythm', src: 'assets/music/wedding-celebration.mp3' },
    ],
  },

  /* ---------- 14. NAVIGATION (labels only) ---------- */
  nav: [
    { id: 'home', label: 'Home' },
    { id: 'story', label: 'Story' },
    { id: 'events', label: 'Events' },
    { id: 'gallery', label: 'Gallery' },
    { id: 'venue', label: 'Venue' },
    { id: 'more', label: 'More' },
  ],
};

export default weddingConfig;
