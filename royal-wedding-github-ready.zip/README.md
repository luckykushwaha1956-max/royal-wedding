# The Royal Wedding Experience

Cinematic Indian wedding invitation website — React + Vite + Tailwind + Framer Motion + GSAP.
Almost everything you edit lives in ONE file: `src/config/weddingConfig.js`.

## 1. Run it on your computer
1. Install Node.js (LTS) from nodejs.org.
2. In this folder: `npm install`
3. `npm run dev`  → open the link shown (also works on your phone on the same Wi-Fi).
4. `npm run build` creates the final website in the `dist/` folder.

## 2. Change the wedding date / time
Open `src/config/weddingConfig.js`. At the very top:
`WEDDING_DATE = '2026-11-26'` and `WEDDING_TIME = '20:00'`.
Countdown, home page and event dates (Haldi = 2 days before, etc.) all update.
To give an event its own date, replace `fromWedding(-2)` with e.g. `'2026-11-24'`.

## 3. Change names, venue, events, family, contacts
All in the same file, each block has a comment. Replace "Groom" / "Bride" with real names there.
- Each event (`events: [...]`) has its own date, time, venue, description, image and map link.
- Venue: fill `mapQuery` (e.g. "Hotel Taj Palace, New Delhi") or paste a Google Maps share link in `mapLink`. GET DIRECTIONS opens that.

## 4. Replace photographs
Put your photo in `public/assets/images/...` with the SAME file name (or change the path in the config).
Folders: `story/`, `events/`, `gallery/`, `venue/`. JPG, 1600px wide is ideal. The included photos are placeholders.

## 5. Add / replace music
Put MP3 files in `public/assets/music/` — keep the names `royal-instrumental.mp3`, `romantic-piano.mp3`,
`shehnai.mp3`, `wedding-celebration.mp3`, or edit `music.tracks` in the config.
The 4 included tracks are short ORIGINAL placeholder tones — replace them with music you have the right to use.
Music starts only after the guest taps ENTER (browsers block autoplay).

## 6. Turn on RSVP saving (Google Sheets, free)
1. Create a Google Sheet. Extensions > Apps Script. Paste `docs/google-sheets-rsvp.gs`.
2. Deploy > New deployment > Web app > Execute as "Me", Access "Anyone". Copy the URL.
3. Paste it in `weddingConfig.js` → `rsvp.endpoint`.
Until then the form honestly tells guests their reply was NOT saved (and offers WhatsApp if `rsvp.whatsapp` is set).

## 7. Put it online (free)
- Netlify: drag-and-drop the `dist/` folder at app.netlify.com/drop after `npm run build`.
- Vercel / GitHub Pages / any hosting also works (build command `npm run build`, output `dist`).
After going live, paste the link in `site.shareUrl` for the Share button.
