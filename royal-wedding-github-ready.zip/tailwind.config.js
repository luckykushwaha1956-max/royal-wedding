/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        midnight: {
          950: '#040815',
          900: '#070d1f',
          800: '#0b1430',
          700: '#111d42',
          600: '#1a2a58',
        },
        gold: {
          200: '#f3e3bd',
          300: '#e9d19a',
          400: '#dcbf7e',
          500: '#c9a45c',
          600: '#a8823a',
        },
        ivory: '#f7f1e3',
        pearl: '#d9d4ca',
        rose: {
          300: '#e8b9bf',
          400: '#d99aa4',
          500: '#c47a88',
        },
      },
      fontFamily: {
        serif: ['"Cormorant Garamond"', 'Georgia', 'serif'],
        display: ['"Playfair Display"', 'Georgia', 'serif'],
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
        script: ['"Great Vibes"', 'cursive'],
      },
      boxShadow: {
        glow: '0 0 40px rgba(220,191,126,0.25)',
      },
    },
  },
  plugins: [],
};
